#include "planif_corto.h"

extern t_log* logger;
extern t_config* config;

pthread_mutex_t mutex_ready;
pthread_mutex_t mutex_blocked;
pthread_mutex_t mutex_new;
pthread_mutex_t mutex_exec;
pthread_mutex_t mutex_blocked_suspended;
pthread_mutex_t mutex_suspended_ready;
pthread_mutex_t mutex_exit;

pthread_mutex_t exec_vacio;


extern sem_t proceso_en_ready;

t_list* cpus_conectadas;
pthread_mutex_t mutex_cpus;

extern t_list* lista_ready;
//pthread_mutex_t mutex_cpu;
pcb_t* proceso_en_cpu;

extern double ALFA;



void inicializar_planificador_corto_plazo(argumentos_planificador_t* args) {
    pthread_t hilo_planificador;
    pthread_create(&hilo_planificador, NULL, planificador_corto_plazo, (void*) args);      //en lugar de poner planificador fifo lo pondria como planif corto plazo para que sea generico
    pthread_detach(hilo_planificador);                                                     //asi despues elegimos algoritmo dentro de la funcion.
    
}

void pasar_a_ready_SRT(pcb_t* pcb, int socket_interrupciones) {
    cambiar_estado(pcb, READY);  // Actualiza métricas

    pthread_mutex_lock(&mutex_ready);

    queue_push(cola_ready, pcb);

    

    t_list* lista_temporal = list_create();
    while (!queue_is_empty(cola_ready)) {
        list_add(lista_temporal, queue_pop(cola_ready));
    }

    list_sort(lista_temporal, comparar_por_rafaga);

    for (int i = 0; i < list_size(lista_temporal); i++) {
        queue_push(cola_ready, list_get(lista_temporal, i));
    }

    list_destroy(lista_temporal);

    pthread_mutex_unlock(&mutex_ready);


    pthread_mutex_lock(&mutex_cpus);

    if (proceso_en_cpu == NULL) {
        log_info(logger, "[SRT] CPU libre, no se necesita interrupción");
        pthread_mutex_unlock(&mutex_cpus);
        return;
    }

    if (proceso_en_cpu->pid == pcb->pid) {
        //log_info(logger, "[SRT] Proceso PID %d ya está en CPU. No se interrumpe a sí mismo.", pcb->pid);
        pthread_mutex_unlock(&mutex_cpus);
        return;
    }

    if (pcb->estimacion < proceso_en_cpu->estimacion) {
        log_info(logger, "[SRT] Interrupción: PID %d (%.2f) < PID %d (%.2f)",
                 pcb->pid, pcb->estimacion,
                 proceso_en_cpu->pid, proceso_en_cpu->estimacion);

        int motivo = MOTIVO_REPLANIFICAR;
        log_info(logger, "Interrupción ENVÍADA");
        if (send(socket_interrupciones, &motivo, sizeof(int), 0) <= 0) {
            log_error(logger, "[SRT] Error al enviar interrupción REPLANIFICAR");
        } 
        else {
            log_info(logger, "[SRT] Interrupción enviada con éxito");
        }
        
    } else {
        log_info(logger, "[SRT] No se interrumpe. PID %d (%.2f) >= PID %d (%.2f)",
                 pcb->pid, pcb->estimacion,
                 proceso_en_cpu->pid, proceso_en_cpu->estimacion);
    }

    pthread_mutex_unlock(&mutex_cpus);
}



void enviar_proceso_a_cpu(pcb_t* pcb, int socket_procesos) {
    t_paquete_proceso paquete;
    paquete.pid = pcb->pid;
    paquete.pc = pcb->pc;
    paquete.estimacion = pcb->estimacion;
    
    if (send(socket_procesos, &paquete, sizeof(t_paquete_proceso), 0) != sizeof(t_paquete_proceso)) {
        perror("Error al enviar paquete de proceso a la CPU");
    } else {
        log_info(logger, "Proceso PID %d enviado a CPU (PC=%d, Est=%.2f)", paquete.pid, paquete.pc, paquete.estimacion);
    }
}

bool comparar_estimacion(void* proceso1, void* proceso2) {
    pcb_t* p1 = (pcb_t*) proceso1;
    pcb_t* p2 = (pcb_t*) proceso2;
    return p1->estimacion < p2->estimacion;
}


void* planificador_corto_plazo(void* args_void) {
    char* algoritmo = config_get_string_value(config, "ALGORITMO_CORTO_PLAZO");

    while (1) {
        log_info(logger, "ESPERANDO QUE SE HABILITE CORTO PLAZO");

        sem_wait(&proceso_en_ready);
        log_info(logger, "CORTO_PLAZO HABILITADO");

        pcb_t* proceso = NULL;

        pthread_mutex_lock(&mutex_ready);
        if (!queue_is_empty(cola_ready)) {
            pthread_mutex_unlock(&mutex_ready);

            // ---------------- FIFO ----------------
            if (strcmp(algoritmo, "FIFO") == 0) {
                log_info(logger, "Planificador corto plazo en FIFO");



                cpu_conectada_t* cpu_libre = elegir_cpu_libre();
                if (!cpu_libre){
                    continue;
                } 

                pthread_mutex_lock(&mutex_ready);
                proceso = queue_pop(cola_ready);
                pthread_mutex_unlock(&mutex_ready);


                if (proceso == NULL) continue;  //esto por si la cola estaba vacia

                if (proceso->temporizador_rafaga == NULL)
                    proceso->temporizador_rafaga = temporal_create();



                pthread_mutex_lock(&mutex_cpus);
                proceso_en_cpu = proceso;
                pthread_mutex_unlock(&mutex_cpus);
                proceso -> cpu_asignada = cpu_libre;
                cpu_libre -> proceso_actual = proceso;
                cpu_libre -> disponible = false;

                log_info(logger, "CPU ocupada con PID: %d", proceso->pid);

                pthread_mutex_lock(&mutex_exec);
                queue_push(cola_exec, proceso);
                pthread_mutex_unlock(&mutex_exec);
                cambiar_estado(proceso, EXEC);

                // log_info(logger, "IMpresion colas CORTO PLAZO proceso mandado a ejecutar");
                // mostrar_cola(cola_new, "NEW", &mutex_new);
                // mostrar_cola(cola_ready, "READY", &mutex_ready);
                // mostrar_cola(cola_exec, "EXEC", &mutex_exec);

                log_info(logger, "enviando proceso PID %d a CPU", proceso->pid);

                enviar_proceso_a_cpu(proceso, cpu_libre->socket_procesos);
                log_info(logger, "[CORTO] Proceso PID %d pasa de READY a EXECUTE", proceso->pid);
            }

            // ---------------- SJF ----------------
            else if (strcmp(algoritmo, "SJF") == 0) {
                log_info(logger, "Planificador corto plazo en SJF");

                pthread_mutex_lock(&mutex_ready);
                list_sort(cola_ready->elements, comparar_por_rafaga);
                proceso = queue_pop(cola_ready);
                pthread_mutex_unlock(&mutex_ready);

                if (proceso == NULL) continue;

                // if(!queue_is_empty(cola_new)){
                //     mostrar_cola(cola_new, "NEW", &mutex_new);
                //     }

                // if(!queue_is_empty(cola_ready)){
                //         mostrar_cola(cola_ready, "READY", &mutex_ready);
                //     }



                if (proceso->temporizador_rafaga == NULL)
                    proceso->temporizador_rafaga = temporal_create();

                cpu_conectada_t* cpu_libre = elegir_cpu_libre();
                if (!cpu_libre) continue;


                pthread_mutex_lock(&mutex_cpus);
                proceso_en_cpu = proceso;
                pthread_mutex_unlock(&mutex_cpus);
                proceso->cpu_asignada = cpu_libre;
                cpu_libre->proceso_actual = proceso;
                cpu_libre->disponible = false;

                pthread_mutex_lock(&mutex_exec);
                queue_push(cola_exec, proceso);
                pthread_mutex_unlock(&mutex_exec);
                cambiar_estado(proceso, EXEC);

                enviar_proceso_a_cpu(proceso, cpu_libre->socket_procesos);

                log_info(logger, "[CORTO] Proceso PID %d pasa de READY a EXECUTE", proceso->pid);
                log_info(logger, "[CORTO] Planificando PID %d con estimación %.2f", proceso->pid, proceso->estimacion);
            }

            // ---------------- SRT ----------------
            else if (strcmp(algoritmo, "SRT") == 0) {
                log_info(logger, "Planificador corto plazo en SRT");

                pthread_mutex_lock(&mutex_ready);
                list_sort(cola_ready->elements, comparar_por_rafaga);
                pcb_t* nuevo_proceso = queue_pop(cola_ready);
                pthread_mutex_unlock(&mutex_ready);

                if (!nuevo_proceso) {
                    log_error(logger, "[SRT] queue_pop devolvió NULL");
                    continue;
                }

                cpu_conectada_t* cpu_libre = elegir_cpu_libre();

                if (cpu_libre) {
                    //log_info(logger, "[SRT] Ejecutando PID %d en CPU libre", nuevo_proceso->pid);     //COMPLETAR, estaria bueno recibi el id de CPU e indicarlo mas claro

                    if (nuevo_proceso->temporizador_rafaga == NULL)
                        nuevo_proceso->temporizador_rafaga = temporal_create();

                    pthread_mutex_lock(&mutex_exec);
                    queue_push(cola_exec, nuevo_proceso);
                    pthread_mutex_unlock(&mutex_exec);

                    //mostrar_cola(cola_exec, "EXEC", mutex_exec);

                    cambiar_estado(nuevo_proceso, EXEC);

                    //nuevo_proceso->cpu_asignada = cpu_libre;
                    //cpu_libre->proceso_actual = nuevo_proceso;

                    pthread_mutex_lock(&mutex_cpus);
                    proceso_en_cpu = nuevo_proceso;
                    pthread_mutex_unlock(&mutex_cpus);

                    //cpu_libre->disponible = false;

                    proceso->cpu_asignada = cpu_libre;
                    cpu_libre->proceso_actual = proceso;
                    cpu_libre->disponible = false;



                    enviar_proceso_a_cpu(nuevo_proceso, cpu_libre->socket_procesos);
                } else {
                    // Comparar con procesos en CPU
                    bool se_desaloja = false;

                    for (int i = 0; i < list_size(cpus_conectadas); i++) {
                        cpu_conectada_t* cpu_actual = list_get(cpus_conectadas, i);

                        pthread_mutex_lock(&mutex_cpus);
                        pcb_t* proceso_actual = cpu_actual->proceso_actual;
                        pthread_mutex_unlock(&mutex_cpus);

                        if (!proceso_actual || nuevo_proceso->pid == proceso_actual->pid)
                            continue;  

                        if (proceso_actual->temporizador_rafaga != NULL) {
                            temporal_stop(proceso_actual->temporizador_rafaga);
                            proceso_actual->rafaga = temporal_gettime(proceso_actual->temporizador_rafaga);
                        } else {
                            proceso_actual->rafaga = 0;
                        }

                        int estimacion_actual = cual_seria_nueva_estimacion(proceso_actual->pid);

                        if (nuevo_proceso->estimacion < estimacion_actual) {
                            log_info(logger, "[SRT] Se desaloja PID %d por PID %d", proceso_actual->pid, nuevo_proceso->pid);

                            int motivo = MOTIVO_REPLANIFICAR;
                            send(cpu_actual->socket_interrupciones, &motivo, sizeof(int), 0);
                            log_info(logger, "[SRT] Se manda motivo REPLANIFICAR");

                            pthread_mutex_lock(&mutex_ready);
                            queue_push(cola_ready, nuevo_proceso);
                            pthread_mutex_unlock(&mutex_ready);

                            mostrar_cola(cola_ready, "READY", &mutex_ready);

                            cambiar_estado(nuevo_proceso, READY);


                            if (nuevo_proceso->cpu_asignada != NULL) {
                                pthread_mutex_lock(&mutex_cpus);
                                nuevo_proceso->cpu_asignada->disponible = true;
                                nuevo_proceso->cpu_asignada->proceso_actual = NULL;
                                nuevo_proceso->cpu_asignada = NULL;
                                pthread_mutex_unlock(&mutex_cpus);
                            }
                            se_desaloja = true;
                            break;
                        }
                    }

                    if (!se_desaloja) {
                        pthread_mutex_lock(&mutex_ready);
                        queue_push(cola_ready, nuevo_proceso);
                        pthread_mutex_unlock(&mutex_ready);

                        mostrar_cola(cola_ready, "READY", &mutex_ready);
                        
                        cambiar_estado(nuevo_proceso, READY);
                    }
                }
            }
        }
        else{
            pthread_mutex_unlock(&mutex_ready);
        }
        
        usleep(1000);  // evita uso excesivo de CPU
    }

    config_destroy(config);
    return NULL;
}

void mostrar_cola(t_queue* cola, char* nombre_cola, pthread_mutex_t* mutex) {

    char buffer_pids[256] = {0};
    char buffer_rafagas[256] = {0};

    strcat(buffer_pids, "PID de COLA [");
    strcat(buffer_pids, nombre_cola);
    strcat(buffer_pids, "]: ");

    //strcat(buffer_rafagas, "Ráfagas de COLA [");
    //strcat(buffer_rafagas, nombre_cola);
    //strcat(buffer_rafagas, "]: ");

    t_list* copia = list_create();

    pthread_mutex_lock(mutex);
    list_add_all(copia, cola->elements);
    pthread_mutex_unlock(mutex);

    for (int i = 0; i < list_size(copia); i++) {
        pcb_t* pcb = list_get(copia, i);

        // PID
        char pid_str[16];
        sprintf(pid_str, "%d", pcb->pid);
        strcat(buffer_pids, pid_str);

        // Rafaga
        char rafaga_str[32];
        sprintf(rafaga_str, "%.2f", pcb->estimacion);
        strcat(buffer_rafagas, rafaga_str);

        if (i < list_size(copia) - 1) {
            strcat(buffer_pids, ",");
            strcat(buffer_rafagas, ",");
        }
    }

    log_info(logger, "%s", buffer_pids);
    log_info(logger, "%s", buffer_rafagas);

    list_destroy(copia);
}



// void mostrar_cola(t_queue* cola, char* nombre_cola, pthread_mutex_t* mutex) {


//     log_info(logger, "Vamos a imprimir colas");

//     char buffer[256] = {0};
//     strcat(buffer, "PID de COLA ["); 
//     strcat(buffer, nombre_cola);
//     strcat(buffer, "]: ");

//     log_info(logger, "lockeamos mutex");

//     t_list* copia = list_create();
    
//     pthread_mutex_lock(mutex); // reemplazar con el mutex adecuado para esa cola
//     log_info(logger, "MUTEX LOCK");
//     list_add_all(copia, cola->elements);
//     pthread_mutex_unlock(mutex);

//     log_info(logger, "copiamos todo en una lista");

//     for (int i = 0; i < list_size(copia); i++) {
//         pcb_t* pcb = list_get(copia, i);
//         char pid_str[16];
//         sprintf(pid_str, "%d", pcb->pid);
//         strcat(buffer, pid_str);
//         if (i < list_size(copia) - 1)
//             strcat(buffer, ",");
//     }

//     log_info(logger, "%s", buffer);
//     list_destroy(copia);

// }


cpu_conectada_t* elegir_cpu_libre() {

    pthread_mutex_lock(&mutex_cpus);
    log_info(logger, "Hay %d cpus conectadas y elijo una", list_size(cpus_conectadas));

    for (int i = 0; i < list_size(cpus_conectadas); i++) {
        if(!list_is_empty(cpus_conectadas)){
            cpu_conectada_t* cpu = list_get(cpus_conectadas, i);
            if (cpu->disponible) {
                log_info(logger, "La CPU %d esta libre asi que la ocupamos", i);
                //cpu->disponible = false;
                //OJOOOOOOO!!!!!!!!!!!!!!!!!
                // no marcar disponible = false hasta que le asignes un proceso.
                //marcar disponible = true cuando se libere la CPU.
                pthread_mutex_unlock(&mutex_cpus);
                return cpu;
            }
        }
    }
    pthread_mutex_unlock(&mutex_cpus);
    
    
    return NULL;  // no hay CPU disponible
}


bool comparar_por_rafaga(void* proceso1, void* proceso2) {
    pcb_t* p1 = (pcb_t*) proceso1;
    pcb_t* p2 = (pcb_t*) proceso2;

    if (!p1 || !p2) return false;

    return p1->rafaga < p2->rafaga;
}

int comparador_para_sort(void* a, void* b) {
    pcb_t* p1 = (pcb_t*) a;
    pcb_t* p2 = (pcb_t*) b;

    if (p1->rafaga < p2->rafaga) return -1;
    if (p1->rafaga > p2->rafaga) return 1;
    return 0;
}

void enviar_interrupcion_a_cpu(int* socket_interrupciones) {
    int codigo_interrupcion = MOTIVO_REPLANIFICAR;

    if (send(*socket_interrupciones, &codigo_interrupcion, sizeof(int),0)) {
        perror("Error al enviar interrupción");
    } else {
        log_info(logger, "SocketInterrupción enviada a la CPU");
    }


    //if(send(*socket_procesos, &(pcb->pid), sizeof(int), 0))
}

void calcular_nueva_estimacion(int pid){
    pcb_t* proceso = buscar_pcb_por_pid(pid);

    int nueva_estimacion = ALFA * (proceso->rafaga) + (1 - ALFA) * (proceso->estimacion);

    proceso->estimacion = nueva_estimacion;
}

int cual_seria_nueva_estimacion(int pid){
    pcb_t* proceso = buscar_pcb_por_pid(pid);
    if (proceso == NULL) {
        log_error(logger, "No se encontró el proceso con PID %d para calcular estimación", pid);
        return 9999; // o un valor grande para que no desaloje a nadie
    }

    double rafaga_actual = proceso->rafaga;

    if (rafaga_actual == 0) {
        log_warning(logger, "Ráfaga actual de PID %d es 0, probablemente porque no se inició temporizador", pid);
    }

    int nueva_estimacion = ALFA * rafaga_actual + (1 - ALFA) * proceso->estimacion;

    log_info(logger, "ESTIMACION NUEVA = %lf * %lf +(1-alfa)* %f", ALFA, rafaga_actual, proceso->estimacion);

    proceso->estimacion = nueva_estimacion;
    return nueva_estimacion;
}

