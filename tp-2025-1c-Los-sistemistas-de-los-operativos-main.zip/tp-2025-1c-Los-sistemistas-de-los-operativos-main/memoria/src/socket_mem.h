#include <utils/hello.h>
#ifndef SOCKET_MEM_H
#define SOCKET_MEM_H
//#define PUERTO_MEMORIA "6666"


//datos hardcodeados
typedef enum
{
	MENSAJE = 0,
	HAY_LUGAR = 1,
	tres=3,
	cuatro=4,
	cinco=5
}op_code;




typedef struct {
    int size;
    void* stream;
} t_buffer;

typedef struct {
    int codigo_operacion;
    t_buffer* buffer;
} t_paquete;


extern t_log* logger;

int iniciar_memoria_servidor(const char*);

int esperar_cliente(int);

void* recibir_buffer(int*, int);

t_list* recibir_paquete(int);

void recibir_mensaje(int);

int recibir_operacion(int);

void enviar_mensaje(char* , int);

void liberar_conexion(int);

void* serializar_paquete(t_paquete* , int );

void eliminar_paquete(t_paquete*);

void responder_mensajes(char* msg, int socket);

void enviar_codigo_operacion(int cod_op, int socket_destino);


char** leer_lineas_archivo(char* path);


#endif