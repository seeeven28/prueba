#include<utils/hello.h>
#include <pcb.h>
#include <semaphore.h>


#ifndef PLANIFICADOR_LARGO_PLAZO_H
#define PLANIFICADOR_LARGO_PLAZO_H




//VOY A ASIGNARLE UN CODIGO A CADA OPCION QUE NECESITE LA CONEXION PARA HACERLO MAS FACIL
//Y NO OLVIDARMELOS

// Códigos entre Kernel y Memoria
#define INIT_PROC   1     // Solicitud de inicialización de proceso
#define EXIT_PROC   2     // Finalización de proceso
#define DUMP_MEMORY 3     // Dump solicitado por syscall

// Respuestas de Memoria al Kernel
#define MEM_OK      100   // Memoria acepta el proceso
#define MEM_ERROR   101   // Memoria no puede alojar el proceso
#define MEM_SWAP_OK 102   // Confirmación de swap
#define MEM_SWAP_ERR 103  // Fallo al intentar swap

extern int socket_memoria; 

extern t_config* config;
extern t_queue* cola_new;
extern t_queue* cola_ready;
extern t_queue* cola_suspended_ready;

//CREO ESTA ESTRUCTURA PARA DARSELA POR EL HILO DEL PLANIFICADOR LARGO





//extern algoritmo_largo_plazo_t algoritmo_largo_plazo;
void esperar_enter();

//void planificador_largo_plazo(t_queue* cola_new, char* algoritmo_planificacion, int* socket_interrupciones);

void inicializar_planificador_largo_plazo();
void* planificador_largo_plazo(void* args_void);

void verificar_inicio_largo_plazo();
int comparador_mas_chico(const void* a, const void* b);
void intentar_iniciar_procesos();

void agregar_proceso_a_new(pcb_t*);
void notificar_finalizacion_proceso();

bool enviar_inicio_a_memoria(pcb_t* pcb, int socket_memoria, char* nombre_archivo);   //COMPLETAR!!! DEBE MANDAR A MEMORIA EL NOMBRE DEL ARCHIVO PSEUDOCODIGO

//////////


bool comparar_por_tamanio(void* a, void* b);
char* recibir_handshake_io(int socket_fd, t_log* logger);


void enviar_peticion_io(int socket_io, uint32_t pid, uint32_t tiempo);

int generar_pid_unico();

void log_metrica_estado(pcb_t* pcb);

void mover_a_estado(pcb_t* pcb, estado_proceso_t nuevo_estado);

void ordenar_cola_por_tamanio(t_queue* cola_ready);

void actualizar_metricas(pcb_t* pcb, estado_proceso_t estado_anterior, long tiempo_actual);

//void despertar_planificador_largo_plazo();

//_____________________DEL LADO DE MEMORIA 
void* atender_kernel(void* arg);
bool verificar_espacio(uint32_t tamanio_requerido);
void reservar_espacio(uint32_t pid, uint32_t tamanio);
void enviar_respuesta(int fd, int codigo_respuesta);
t_list* recibir_lista_instrucciones(int socket);
bool enviar_desuspender_a_memoria(pcb_t* proceso, int conexion_memoria);

void finalizar_proceso(pcb_t* pcb, t_queue* cola_new, t_queue* cola_suspended_ready, char* nombre_archivo);

#endif // SOCKET_KERNEL_H_