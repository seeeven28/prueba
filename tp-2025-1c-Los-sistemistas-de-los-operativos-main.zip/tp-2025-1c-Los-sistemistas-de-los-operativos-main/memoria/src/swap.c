#include "swap.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <commons/string.h>
#include <commons/log.h>

extern t_log* logger;
extern void* espacio_usuario;
//extern bool marcos_usados[];
extern bool* marcos_usados;
extern int TAM_PAGINA;

FILE* archivo_swap;

char* PATH_SWAP;
int retardo_swap;

void inicializar_swap(char* path, int retardo) {
    PATH_SWAP = strdup(path);
    retardo_swap = retardo;

    archivo_swap = fopen(PATH_SWAP, "w+b");
    if (!archivo_swap) {
        perror("No se pudo abrir el archivo SWAP");
        exit(EXIT_FAILURE);
    }
}

bool escribir_en_swap(int pid, void* contenido, int tamanio) {
    fseek(archivo_swap, pid * 4096, SEEK_SET);  // Offset por PID
    size_t escrito = fwrite(contenido, 1, tamanio, archivo_swap);
    fflush(archivo_swap);
    return escrito == tamanio;
}

void* leer_de_swap(int pid, int tamanio) {
    void* buffer = malloc(tamanio);
    fseek(archivo_swap, pid * 4096, SEEK_SET);
    fread(buffer, 1, tamanio, archivo_swap);
    return buffer;
}

void eliminar_proceso_swap(int pid) {
    void* zeros = calloc(1, 4096); // limpio
    fseek(archivo_swap, pid * 4096, SEEK_SET);
    fwrite(zeros, 1, 4096, archivo_swap);
    fflush(archivo_swap);
    free(zeros);
}

void cerrar_swap() {
    fclose(archivo_swap);
}

bool suspender_a_swap(int pid) {
    usleep(retardo_swap);

    proceso_memoria_t* proceso = buscar_proceso(pid);
    if (!proceso) return false;

    int offset = pid * 4096;  // Este valor puede mejorar con tamaño real
    fseek(archivo_swap, offset, SEEK_SET);

    for (int i = 0; i < proceso->cantidad_paginas; i++) {
        entrada_tabla_pagina_t* entrada = obtener_entrada(proceso, i);
        if (!entrada || !entrada->presente) continue;

        void* origen = espacio_usuario + entrada->marco * TAM_PAGINA;
        fwrite(origen, 1, TAM_PAGINA, archivo_swap);
        marcos_usados[entrada->marco] = false;
        entrada->presente = false;
    }

    fflush(archivo_swap);
    log_info(logger, "[SWAP] Proceso %d suspendido a swap", pid);
    return true;
}

bool desuspender_de_swap(int pid) {
    usleep(retardo_swap);
    proceso_memoria_t* proceso = buscar_proceso(pid);
    if (!proceso) return false;

    int offset = pid * 4096;
    fseek(archivo_swap, offset, SEEK_SET);

    for (int i = 0; i < proceso->cantidad_paginas; i++) {
        entrada_tabla_pagina_t* entrada = obtener_entrada(proceso, i);
        if (!entrada) continue;

        int marco = obtener_marco_libre();
        if (marco == -1) {
            log_error(logger, "[SWAP] No hay marcos disponibles para desuspender PID %d", pid);
            return false;
        }

        entrada->marco = marco;
        entrada->presente = true;
        entrada->modificado = false;

        void* destino = espacio_usuario + marco * TAM_PAGINA;
        fread(destino, 1, TAM_PAGINA, archivo_swap);
    }

    log_info(logger, "[SWAP] Proceso %d restaurado desde swap", pid);
    return true;
}

