#ifndef MEMORIA_H
#define MEMORIA_
#include<utils/hello.h>
#include "metricas.h"
#include <swap.h>
#include <semaphore.h>

//comunicacion con CPU
#define PEDIR_INSTRUCCION 11 
#define SOLICITAR_MARCO 12
#define SOLICITAR_PAGINA 13

#define INSTR_NOOP        501
#define INSTR_WRITE       502
#define INSTR_READ        503
#define INSTR_GOTO        504
#define INSTR_IO          505
#define INSTR_INIT_PROC   506
#define INSTR_DUMP_MEMORY 507
#define INSTR_EXIT        508

//cache CPU
#define ESCRIBIR_PAGINA 509

#include <utils/hello.h>

//typedef struct {
//    int pid;
//    char** instrucciones;
//    int cantidad_instrucciones;
//} pseudocodigo_t;

//typedef struct {
//    entrada_tabla_pagina_t** niveles; // arreglo de punteros a otros niveles
//} tabla_pagina_t;





extern t_list* metricas;
extern void agregar_metrica(int pid);

bool finalizar_proceso_en_memoria(int pid);


void iniciar_memoria();
void liberar_memoria();

char** obtener_instrucciones_para_pid(int pid);
int obtener_espacio_libre_mock(); // Devuelve un valor fijo
void inicializar_marcos_usados(int marcos);
void destruir_tabla(tabla_paginas_t* tabla);

//void imprimir_tablas_pagina(tabla_paginas_t* tabla, int nivel, int entradas_por_tabla);
void imprimir_tablas_pagina(tabla_paginas_t* tabla, int nivel, int entradas_por_tabla,int* pagina_logica_actual, int paginas_instrucciones, t_list* instrucciones);


t_log* iniciar_logger(void);

#endif
