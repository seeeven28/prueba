#include <utils/hello.h>
#include <socket_io.h>

extern t_config* config;
extern t_log* logger;

int iniciar_cliente(const char* ip, const char* puerto){
    struct addrinfo hints, *server_info;
    int err;

    memset(&hints, 0, sizeof(hints));

    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags = AI_PASSIVE;

    err = getaddrinfo(ip, puerto, &hints, &server_info);
    if (err != 0) {
        perror("IO: ERROR GETADDRINFO");
        exit(EXIT_FAILURE);
    }

    int fd_conexion = socket(server_info->ai_family,
                            server_info->ai_socktype,
                            server_info->ai_protocol);

    err = connect(fd_conexion, server_info->ai_addr, server_info->ai_addrlen);
    if (err != 0) {
        perror("IO: Error al conectar");
        close(fd_conexion);
    }
    else{
        printf("IO: conectado con exito\n");
    }
    freeaddrinfo(server_info);
    return fd_conexion;
}


t_io_request* recibir_io_request(int socket_fd) {
    t_io_request* request = malloc(sizeof(t_io_request));
    if (!request) return NULL;

    log_info(logger, "Esperamos recibir pid y tiempo");
    if (recv(socket_fd, &(request->pid), sizeof(int), MSG_WAITALL) <= 0) {
        free(request);
        return NULL;
    }
    log_info(logger, "recibimos request PID: %d", request->pid);

    
    if (recv(socket_fd, &(request->tiempo), sizeof(int), MSG_WAITALL) <= 0) {
        free(request);
        return NULL;
    }
    log_info(logger, "recibimos request TIEMPO: %d", request->tiempo);

    return request;
}

void enviar_finalizacion_io(int socket_fd, int pid) {
    if (socket_fd <= 0) {
        printf("[ERROR] Socket inválido: %d\n", socket_fd);
        return;
    }

    uint8_t codigo = OPCODE_IO_FIN;

    if (send(socket_fd, &codigo, sizeof(uint8_t), 0) <= 0) {
        perror("[ERROR] Fallo al enviar código de finalización IO");
    }

    if (send(socket_fd, &pid, sizeof(int), 0) <= 0) {
        perror("[ERROR] Fallo al enviar PID de finalización IO");
    }
}
