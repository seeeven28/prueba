#include <utils/hello.h>
#include <socket_mem.h>
#include <mem.h>
#include <mem_largo_plazo.h>
#include <metricas.h>
#include <swap.h>

t_dictionary* pseudocodigos;
extern FILE* swapfile;

t_log* logger;
t_config* config;
t_list* metricas_procesos;

extern t_list* procesos_en_memoria;
//extern bool marcos_usados[];

extern int cantidad_niveles_tabla;

void* espacio_usuario = NULL;

void* espacio_usuario;
void* memoria_principal;
int tam_memoria;
int cantidad_niveles_tablas = 0;
int MAX_MARCOS;
int TAM_PAGINA;
bool* marcos_usados;
int entradas_por_pagina;

sem_t sem_conexion_kernel;      //PARA ACEPTAR CONEXIONES DE KERNEL UNA A LA VEZ


//#define MAX_MARCOS 128

t_log* iniciar_logger(void)
{   
    t_log* nuevo_logger= log_create("mem.log", "MEMORIA logger", 1, LOG_LEVEL_INFO);
    if(nuevo_logger == NULL)
    {
        perror("No se pudo crear el log \n");
        exit(EXIT_FAILURE);
    }
    return nuevo_logger;
}

t_config* iniciar_config(void){
    t_config* nuevo_config = config_create("/home/utnso/tp-2025-1c-Los-sistemistas-de-los-operativos/memoria/src/mem.config");

    if(nuevo_config==NULL){
        perror("Error al cargar el config \n");
        exit(EXIT_FAILURE);
    }
    
    return nuevo_config;    
}

void* aceptar_conexiones_cpu(void* arg) {
    int servidor_cpu = *(int*)arg;
    log_info(logger, "En este hilo aceptamos CPUS constantemente. Siempre esperamos a una nueva");
    while (1) {
        int* socket_cliente = malloc(sizeof(int));
        *socket_cliente = esperar_cliente(servidor_cpu);
        log_info(logger, "Nueva CPU conectada");
        pthread_t hilo_cpu;
        pthread_create(&hilo_cpu, NULL, atender_conexion_cpu, socket_cliente);
        pthread_detach(hilo_cpu);
    }
}

void* aceptar_conexiones_kernel(void* arg) {
    int servidor_kernel = *(int*)arg;
    
    while (1) {
        int* socket_cliente = malloc(sizeof(int));
        *socket_cliente = esperar_cliente(servidor_kernel);
        log_info(logger, "Kernel conectado");
        pthread_t hilo_kernel;
        pthread_create(&hilo_kernel, NULL, atender_conexion_kernel, socket_cliente);
        pthread_detach(hilo_kernel);

        sem_post(&sem_conexion_kernel);
    }


}

void liberar_memoria() {
    dictionary_destroy_and_destroy_elements(pseudocodigos, free);
}

void inicializar_memoria_principal() {
    tam_memoria = config_get_int_value(config, "TAM_MEMORIA");
    memoria_principal = malloc(tam_memoria);
    if (!memoria_principal) {
        log_error(logger, "Fallo al asignar memoria principal");
        exit(EXIT_FAILURE);
    }
    log_info(logger, "Memoria principal inicializada con %d bytes", tam_memoria);
}

bool finalizar_proceso_en_memoria(int pid) {

    log_info(logger, "Buscamos el pid por el proceso");
    proceso_memoria_t* proceso = buscar_proceso(pid);

    //SEGURO ESTO FALLA PORQUE HAY QUE BUSCAR EL MARCO EN LA JERARQUICA MULTINIVEL

    if (!proceso){
        log_info(logger, "FIN mem: Proceso invalido %d", proceso->pid);
        return false;
    }

    log_info(logger, "HALLADO PID %d", proceso->pid);
    log_info(logger, "HALLADO cant pags %d", proceso->cantidad_paginas);

    log_info(logger, "Finalizando el proceso es PID %d", proceso->pid);




    for (int i = 0; i < proceso->cantidad_paginas; i++) {
        entrada_tabla_pagina_t* entrada = obtener_entrada(proceso, i);
        if (entrada && entrada->marco >= 0 && entrada->marco < MAX_MARCOS) {
            marcos_usados[entrada->marco] = false;
        }
    }
    log_info(logger, "VAMOS A IMPRIMIR METRICA Y LIBERAR");
    imprimir_metricas_y_liberar(pid);

    char* pid_str = string_itoa(pid);
    t_list* instrucciones = dictionary_remove(pseudocodigos, pid_str);
    if (instrucciones) list_destroy_and_destroy_elements(instrucciones, free);


    bool _match_pid(void* elem) { return ((proceso_memoria_t*)elem)->pid == pid; }
    list_remove_by_condition(procesos_en_memoria, _match_pid);

    eliminar_proceso_swap(pid);

    // Liberar las tablas
    destruir_tabla(proceso->tabla_primer_nivel);


    //free(proceso->tabla_primer_nivel);

    free(proceso);

    return true;
}


void destruir_tabla(tabla_paginas_t* tabla) {
    int niveles = config_get_int_value(config, "CANTIDAD_NIVELES");

    log_info(logger, "[LIBERANDO] Nivel actual: %d", tabla->nivel);

    for (int i = 0; i < list_size(tabla->entradas); i++) {
        void* elem = list_get(tabla->entradas, i);
        if (tabla->nivel == niveles - 1) {
            free((entrada_tabla_pagina_t*)elem);
        } else {
            destruir_tabla((tabla_paginas_t*)elem);
        }
    }

    list_destroy(tabla->entradas);
    free(tabla);
}




void inicializar_marcos_usados(int marcos){
    marcos_usados = malloc(marcos * sizeof(bool));
    if(marcos_usados == NULL){
        log_error(logger, "Error al asignar los marcos");
        exit(EXIT_FAILURE);
    }

    for(int i=0; i<MAX_MARCOS; i++){
        marcos_usados[i] = false;
    }
}

int main(int argc, char* argv[]) {
    
    logger = iniciar_logger();
    config = iniciar_config();
    log_info(logger,"MEMORIA inciando...");
    

    metricas = list_create();

    char* puerto_memoria_kernel = config_get_string_value(config, "PUERTO_ESCUCHA_KERNEL");
    char* puerto_memoria_cpu = config_get_string_value(config, "PUERTO_ESCUCHA_CPU");    
    char* path_scripts = config_get_string_value(config, "PATH_INSTRUCCIONES"); //aca buscamos el pseudocodigo
    cantidad_niveles_tablas = config_get_int_value(config, "CANTIDAD_NIVELES");
    entradas_por_pagina = config_get_int_value(config, "ENTRADAS_POR_TABLA");
    

    iniciar_memoria();  //se crea el diccionario y una lista para almacenar los procesos en memoria
    inicializar_memoria_principal();

    char* pathswap = config_get_string_value(config, "PATH_SWAPFILE");
    int retardo_swap = config_get_int_value(config, "RETARDO_SWAP");
    inicializar_swap(pathswap, retardo_swap);

    // int tam_memoria = config_get_int_value(config, "TAM_MEMORIA");
    // espacio_usuario = malloc(tam_memoria);

    TAM_PAGINA = config_get_int_value(config, "TAM_PAGINA");
    int TAM_MEMORIA = config_get_int_value(config, "TAM_MEMORIA");

    MAX_MARCOS = TAM_MEMORIA / TAM_PAGINA;

    inicializar_marcos_usados(MAX_MARCOS);




    log_info(logger,"busco scripts en %s", path_scripts);

    
    //INICIO HILOS QUE ESPERARAN CONEXIONES. El esperar_cliente() se apropiaba y no permitia que se conecten multiples modulos
    int servidor_cpu = iniciar_memoria_servidor(puerto_memoria_cpu);
    int servidor_kernel = iniciar_memoria_servidor(puerto_memoria_kernel);

    log_info(logger, "Arrancamos hilos");

    pthread_t hilo_aceptar_cpu;
    pthread_create(&hilo_aceptar_cpu, NULL, aceptar_conexiones_cpu, &servidor_cpu);
    pthread_detach(hilo_aceptar_cpu);

    pthread_t hilo_aceptar_kernel;
    pthread_create(&hilo_aceptar_kernel, NULL, aceptar_conexiones_kernel, &servidor_kernel);
    pthread_detach(hilo_aceptar_kernel);
    
    // int socket_kernel = esperar_cliente(servidor_memoria_kernel);
    // log_info(logger, "Kernel conectado");

    // pthread_t hilo_kernel;
    // pthread_create(&hilo_kernel, NULL, atender_conexion_kernel, &socket_kernel);
    // pthread_detach(hilo_kernel);
         
    
    while(1){
        int pod =1;
    }
    //log_destroy(logger);
    //cerrar_swap();

    return 0;
}

// void imprimir_tablas_pagina(tabla_paginas_t* tabla, int nivel, int entradas_por_tabla) {
//     if (!tabla) return;

//     for (int i = 0; i < list_size(tabla->entradas); i++) {
//         void* entrada = list_get(tabla->entradas, i);
        
//         if (nivel == 1) {
//             entrada_tabla_pagina_t* ep = (entrada_tabla_pagina_t*)entrada;
//             log_info(logger, "Nivel %d - Entrada %d → Marco: %d | Presente: %s", 
//                 nivel, i, ep->marco, ep->presente ? "Sí" : "No");
//         } else {
//             log_info(logger, "Nivel %d - Subtabla %d ↓ - PID: %d", nivel, i, tabla->pid);
//             tabla_paginas_t* subtabla = (tabla_paginas_t*)entrada;
//             imprimir_tablas_pagina(subtabla, nivel - 1, entradas_por_tabla);
//         }
//     }
// }

void imprimir_tablas_pagina(tabla_paginas_t* tabla, int nivel, int entradas_por_tabla, int* pagina_logica_actual, int paginas_instrucciones, t_list* instrucciones){
    if (!tabla) return;

    for (int i = 0; i < list_size(tabla->entradas); i++) {
        void* entrada = list_get(tabla->entradas, i);
        
        if (nivel == 1) {
            entrada_tabla_pagina_t* ep = (entrada_tabla_pagina_t*)entrada;

            // Calculamos qué instrucción corresponde
            if (*pagina_logica_actual < paginas_instrucciones) {
                int instruccion_index = *pagina_logica_actual * entradas_por_tabla;

                // Mostrar todas las instrucciones que caben en esta página
                char* instrucciones_en_pagina = string_new();
                for (int j = 0; j < entradas_por_tabla; j++) {
                    int idx = instruccion_index + j;
                    if (idx >= list_size(instrucciones)) break;
                    char* instr = list_get(instrucciones, idx);
                    string_append_with_format(&instrucciones_en_pagina, "%s ", instr);
                }

                log_info(logger, 
                    "Nivel %d - Entrada %d → Marco: %d | Presente: %s | Instrucciones: [%s]", 
                    nivel, i, ep->marco, ep->presente ? "Sí" : "No", instrucciones_en_pagina
                );

                free(instrucciones_en_pagina);
            } else {
                log_info(logger, 
                    "Nivel %d - Entrada %d → Marco: %d | Presente: %s | Datos", 
                    nivel, i, ep->marco, ep->presente ? "Sí" : "No"
                );
            }

            (*pagina_logica_actual)++;

        } else {
            log_info(logger, "Nivel %d - Subtabla %d ↓ - PID: %d", nivel, i, tabla->pid);
            tabla_paginas_t* subtabla = (tabla_paginas_t*)entrada;
            imprimir_tablas_pagina(subtabla, nivel - 1, entradas_por_tabla, pagina_logica_actual, paginas_instrucciones, instrucciones);
        }
    }
}
