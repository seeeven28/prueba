#include <utils/hello.h>
#include <kernel.h>
#include <socket_kernel.h>
#include <pcb.h>
#include <planif_corto.h>

extern pthread_mutex_t mutex_new;
extern pthread_mutex_t mutex_ready;
extern pthread_mutex_t mutex_blocked;
extern pthread_mutex_t mutex_exec;
extern pthread_mutex_t mutex_blocked_suspended;
extern pthread_mutex_t mutex_suspended_ready;
extern pthread_mutex_t mutex_exit;

extern t_queue* cola_new;
extern t_queue* cola_ready;
extern t_queue* cola_exec;
extern t_queue* cola_blocked;
extern t_queue* cola_blocked_suspended;
extern t_queue* cola_suspended_ready;
extern t_queue* cola_exit;

extern pthread_mutex_t mutex_cpus;
extern pcb_t* proceso_en_cpu;
//extern pthread_mutex_t mutex_cpu;
extern sem_t sem_largo_plazo;
extern sem_t proceso_en_ready;


extern t_list* cpus_conectadas;
extern pcb_t* proceso_en_cpu;

t_list* dispositivos_io;
pthread_mutex_t mutex_dispositivos_io;

extern int ESTIMACION_INICIAL;

extern t_list* lista_ready;

t_log* iniciar_logger(void)
{   
    t_log* nuevo_logger= log_create("kernel.log", "KERNEL logger", 1, LOG_LEVEL_INFO);
    if(nuevo_logger == NULL)
    {
        perror("No se pudo crear el log \n");
        exit(EXIT_FAILURE);
    }
    return nuevo_logger;
}
                                        
t_config* iniciar_config(void){
    t_config* nuevo_config = config_create("/home/utnso/tp-2025-1c-Los-sistemistas-de-los-operativos/kernel/src/kernel.config");

    if(nuevo_config==NULL){
        perror("Error al cargar el config \n");
        exit(EXIT_FAILURE);
    }
    
    return nuevo_config;    
}

void iterator(void* value) {
    char* val = (char*) value;
    log_info(logger, "%s", val);
}

void* aceptar_cpus(void* args_void) {
    argumentos_aceptar_cpu_t* args = (argumentos_aceptar_cpu_t*) args_void;
    int servidor_procesos = args->servidor_procesos;
    int servidor_interrupciones = args->servidor_interrupciones;
    char* algoritmo = config_get_string_value(config, "ALGORITMO_CORTO_PLAZO");

    while (1) {
        int socket_dispatch = esperar_cliente(servidor_procesos);
        if (socket_dispatch == -1) {
            log_error(logger, "Error al aceptar cliente en DISPATCH");
            continue;
        }
    log_info(logger, "CPU conectada a DISPATCH");

    int socket_interrupt = esperar_cliente(servidor_interrupciones);
    if (socket_interrupt == -1) {
        log_error(logger, "Error al aceptar cliente en INTERRUPT");
        continue;
    }
    log_info(logger, "CPU conectada a INTERRUPT");

    cpu_conectada_t* nueva_cpu = malloc(sizeof(cpu_conectada_t));
    nueva_cpu->socket_procesos = socket_dispatch;
    nueva_cpu->socket_interrupciones = socket_interrupt;
    nueva_cpu->disponible = true;
    pthread_mutex_lock(&mutex_cpus);
    nueva_cpu->proceso_actual = NULL;
    pthread_mutex_unlock(&mutex_cpus);

    pthread_mutex_lock(&mutex_cpus);
    list_add(cpus_conectadas, nueva_cpu);
    pthread_mutex_unlock(&mutex_cpus);

    pthread_t hilo_procesos, hilo_interrupciones;

    argumentos_planificador_t* args_procesos = malloc(sizeof(argumentos_planificador_t));
    args_procesos->socket_procesos = socket_dispatch;
    args_procesos->socket_interrupciones = socket_interrupt;
    args_procesos->algoritmo_ingreso_ready = algoritmo;
    

    argumentos_planificador_t* args_interrupciones = malloc(sizeof(argumentos_planificador_t));
    args_interrupciones->socket_procesos = socket_dispatch;
    args_interrupciones->socket_interrupciones = socket_interrupt;

    pthread_create(&hilo_procesos, NULL, manejar_cpu_procesos, args_procesos);
    pthread_create(&hilo_interrupciones, NULL, manejar_cpu_interrupciones, args_interrupciones);
        

    pthread_detach(hilo_procesos);
    pthread_detach(hilo_interrupciones);

    }

}  

void* manejar_cpu_procesos(void* arg) {
    argumentos_planificador_t* args = (argumentos_planificador_t*) arg;

    int socket = args->socket_procesos;
    int socket_interrupciones = args->socket_interrupciones;
    //int socket_io = args->socket_io;
    char* algoritmo_cola_ready = args->algoritmo_ingreso_ready;
    free(arg);

    int contador_de_procesos = 1;
    int contador_de_exit = 0;

    while (1) {
        //int codigo;
        //log_info(logger, "ESPERANDO CODIGO DE SYSCALL O ALGO");
        //int recibido = recv(socket, &codigo, sizeof(op_code), MSG_WAITALL);

        //if (recibido <= 0) {
        //    log_info(logger, "[MANEJO CPU] CPU desconectada.");
        //    break;
        //}

        t_devolucion_proceso devolucion;
        if (recv(socket, &devolucion, sizeof(t_devolucion_proceso), MSG_WAITALL) <= 0) {
            log_error(logger, "[MANEJO CPU] Error al recibir t_devolucion_proceso");
            break;
        } 

        log_info(logger, "DEVOLUCION- PID %d - PC %d - Motivo %d", devolucion.pid, devolucion.pc, devolucion.motivo);
        
        if(!queue_is_empty(cola_new)){
                mostrar_cola(cola_new, "NEW", &mutex_new);
            }
        
        if(!queue_is_empty(cola_ready)){
                mostrar_cola(cola_ready, "READY", &mutex_ready);
                
                // pthread_mutex_lock(&mutex_ready);
                // sem_post(&proceso_en_ready);
                // pthread_mutex_unlock(&mutex_ready);
            }

        if(!queue_is_empty(cola_exec)){
                mostrar_cola(cola_exec, "EXEC", &mutex_exec);
            }
 


        log_info(logger, "Buscamos pcb para el pid %d", devolucion.pid);
        pcb_t* pcb = buscar_pcb_por_pid(devolucion.pid);
        
        if (pcb == NULL) {
            log_error(logger, "PCB no encontrado para PID %d", devolucion.pid);
            continue;
        }
        log_info(logger, "Encontramos el pcb por el pid");


        pcb->pc = devolucion.pc;



        //pcb->pc = devolucion.pc;

        switch (devolucion.motivo) {

            case INIT_PROC: {
                log_info(logger, "_____________SYSCALL INIT PROC_____________");
                
                log_info(logger, "[MANEJO CPU] Ejecutando syscall INIT_PROC para -PID: %d -PC: %d", pcb->pid, pcb->pc -1);


                pthread_mutex_lock(&mutex_exec);
                pcb_t* pcb_que_sale = queue_pop(cola_exec);
                pthread_mutex_unlock(&mutex_exec);

                if (pcb_que_sale == NULL || pcb_que_sale->pid != pcb->pid) {
                    log_error(logger, "ERROR DE ESTADO: El proceso en EXEC no es el que llamó a INIT_PROC.");
                }



                char* archivo = recv_param_string(socket); 
                int tamanio;
                recv_param_int(socket, &tamanio);
                
                //log_info(logger,"[INIT_PROC] Creando Proceso: %s con tamaño: %d", pcb->pid, archivo, tamanio);

                pcb_t* proceso_nuevo = crear_proceso_pseudocodigo(archivo, tamanio);

                free(archivo);

                log_info(logger, "Devolviendo proceso padre PID %d a READY", pcb->pid);                
                cambiar_estado(pcb, READY);
                pthread_mutex_lock(&mutex_ready);
                queue_push(cola_ready, pcb);
                pthread_mutex_unlock(&mutex_ready);


                if (proceso_nuevo == NULL) {
                    log_error(logger, "[INIT_PROC] Error al crear proceso hijo");
                    // Importante: si la creacion falla, el proceso original debe volver a READY de todas formas.
                } else {
                    // si la creacion fue exitosa, pone el nuevo proceso en NEW.
                    cambiar_estado(proceso_nuevo, NEW);
                    pthread_mutex_lock(&mutex_new);
                    queue_push(cola_new, proceso_nuevo);
                    pthread_mutex_unlock(&mutex_new);

                    log_info(logger, "Habilito planificador largo");
                    sem_post(&sem_largo_plazo); // despierta al planificador de largo plazo.
                }

                log_info(logger,"LIBERO CPU");
                cpu_conectada_t* cpu_en_uso = pcb->cpu_asignada;
                pthread_mutex_lock(&mutex_cpus);
                (cpu_en_uso) -> disponible = true;
                pcb->cpu_asignada = NULL;
                pthread_mutex_unlock(&mutex_cpus);


                // Devuelve el proceso original (el que llamó a INIT_PROC) a la cola READY.




                // Lo reencolamos a READY para que siga ejecutando su código
                // if (strcmp(algoritmo_cola_ready, "SRT") == 0) {
                //     pasar_a_ready_SRT(pcb, socket_interrupciones);
                // } 
                // else {
                //     pthread_mutex_lock(&mutex_ready);
                //     queue_push(cola_ready, pcb);
                //     pthread_mutex_unlock(&mutex_ready);
                //     cambiar_estado(pcb, READY);

                //     queue_pop(cola_exec);

                //     mostrar_cola(cola_ready, "NEW", mutex_ready);

                //     sem_post(&proceso_en_ready);
                // }
                
                // Lo mandamos a NEW

                // pthread_mutex_lock(&mutex_new);
                // queue_push(cola_new, proceso_nuevo);
                // pthread_mutex_unlock(&mutex_new);
                // cambiar_estado(proceso_nuevo, NEW);


                // mostrar_cola(cola_new, "NEW", &mutex_new);
                // mostrar_cola(cola_ready, "READY", &mutex_ready);
                // mostrar_cola(cola_exec, "EXEC", &mutex_exec);
                // mostrar_cola(cola_blocked, "BLOCKED", &mutex_blocked);
                // mostrar_cola(cola_blocked_suspended, "BLOCKED SUSP", &mutex_blocked_suspended);
                // mostrar_cola(cola_suspended_ready, "SUSP READY", &mutex_suspended_ready);
                // mostrar_cola(cola_exit, "EXIT", &mutex_exit);              
                
            
                log_info(logger, "Habilito planificador corto por INIT PROC");
                //sem_post(&proceso_en_ready);
                contador_de_procesos += 1;  //esto cuenta cuantos PID andan dando vueltas para saber cuando es el fin del programa
                                            //ejecuto un corte en el ultimo EXIT
                break;
            }

            case INSTR_IO: {
                log_info(logger, "_____________SYSCALL IO_____________");
                log_info(logger, "[MANEJO CPU] Ejecutando syscall IO para PID %d", pcb->pid);
                int tiempo;

                pthread_mutex_lock(&mutex_exec);
                pcb_t* pcb_bloqueado = queue_pop(cola_exec);
                pthread_mutex_unlock(&mutex_exec);

                if (pcb_bloqueado == NULL || pcb_bloqueado->pid != pcb->pid) {
                    log_error(logger, "ERROR DE ESTADO: El proceso en EXEC no es el que pidió I/O.");
                    // Decide cómo manejar este error grave. Por ahora, continuamos.
                }
  
                log_info(logger,"LIBERO CPU");
                cpu_conectada_t* cpu_en_uso = pcb->cpu_asignada;
                pthread_mutex_lock(&mutex_cpus);
                cpu_en_uso->disponible = true;
                cpu_en_uso->proceso_actual = NULL; 
                pcb->cpu_asignada = NULL;
                proceso_en_cpu = NULL;             
                pthread_mutex_unlock(&mutex_cpus);

                log_info(logger, "Habilito planificador corto por IO");
                sem_post(&proceso_en_ready);

                if (strcmp(algoritmo_cola_ready, "SJF") == 0){

                    if (pcb->temporizador_rafaga != NULL) {
                        temporal_stop(pcb->temporizador_rafaga);
                        pcb->rafaga = temporal_gettime(pcb->temporizador_rafaga);
                        } 
                        else {
                            pcb->rafaga = 0;
                        }

                    int estimacion_nueva = cual_seria_nueva_estimacion(pcb->pid);
                    pcb->estimacion = estimacion_nueva;

                    //list_sort(cola_ready->elements, comparar_por_rafaga);

                    log_info(logger, "Se recalcula la estimacion para PID: %d -> EST: %d", pcb->pid, estimacion_nueva);
                }


                recv(socket, &tiempo, sizeof(int), MSG_WAITALL);
                //log_info(logger, "Recibimos tiempo: %d", tiempo);
                char* dispositivo = recv_param_string(socket);
                //log_info(logger, "Recibimos dispositivo: %s", dispositivo);
                syscall_io(pcb, dispositivo, tiempo);
                free(dispositivo);

                break;
            }

            case INSTR_DUMP_MEMORY: {
                log_info(logger, "_____________SYSCALL DUMP MEMORY_____________");
                log_info(logger, "[MANEJO CPU] Ejecutando syscall DUMP_MEMORY para PID %d", pcb->pid);
                // Aquí debe trabajar la parte que maneje el DUMP_MEMORY
                break;
            }

            case MOTIVO_EXIT: {
                log_info(logger, "_____________SYSCALL EXIT_____________");
                log_info(logger, "[MANEJO CPU] Ejecutando syscall EXIT para PID %d", pcb->pid);


                pthread_mutex_lock(&mutex_exec);
                pcb_t* pcb_finalizado = queue_pop(cola_exec);
                pthread_mutex_unlock(&mutex_exec);

                if (pcb_finalizado == NULL || pcb_finalizado->pid != pcb->pid) {
                    log_error(logger, "ERROR DE ESTADO: El proceso en EXEC no es el que finalizó.");
                }


                // pthread_mutex_lock(&mutex_ready);
                // if(!queue_is_empty(cola_ready)){
                //     queue_pop(cola_ready);
                // }
                // pthread_mutex_unlock(&mutex_ready);

                cpu_conectada_t* cpu_en_uso = pcb->cpu_asignada;
                if (cpu_en_uso == NULL) {
                    log_error(logger, "[ERROR] La CPU asignada al proceso PID %d es NULL", pcb->pid);
                    break;
                }
                pthread_mutex_lock(&mutex_cpus);
                cpu_en_uso->disponible = true;
                cpu_en_uso->proceso_actual = NULL;
                pcb->cpu_asignada = NULL;
                proceso_en_cpu = NULL;
                pthread_mutex_unlock(&mutex_cpus);

                log_info(logger, "Liberamos cpus y ahora finalizamos el PROCESO");
            

                if (pcb->temporizador_rafaga) {
                    log_info(logger, "Detenemos rafagas");
                    temporal_destroy(pcb->temporizador_rafaga);
                    pcb->temporizador_rafaga = NULL;
                }
                log_info(logger, "RAFAGAS DETENIDAS");
    
                finalizar_proceso(pcb, cola_new, cola_suspended_ready, pcb->nombre_archivo);



                // pthread_mutex_lock(&mutex_exec);
                // pcb_t *proceso = queue_pop(cola_exec);
                // pthread_mutex_unlock(&mutex_exec);

                // pthread_mutex_lock(&mutex_ready);
                // queue_push(cola_ready, proceso);
                // pthread_mutex_unlock(&mutex_ready);

                // if(strcmp(algoritmo_cola_ready,"FIFO") == 0 || strcmp(algoritmo_cola_ready,"SJF") == 0){
                //     pthread_mutex_lock(&mutex_ready);
                //     if(!queue_is_empty(cola_ready)){

                //         log_info(logger, "PROCESO PID: %d TERMINADO LO SACO DE LA COLA READY", pcb->pid);
                //               //ACA INTENTO ELIMINAR PROCESO DE LA COLA     
                //     }
                //     pthread_mutex_unlock(&mutex_ready);
                // }


                // if (strcmp(algoritmo_cola_ready, "SJF") == 0){
                //     list_sort(cola_ready->elements, comparar_por_rafaga);
                //     }

               
                // mostrar_cola(cola_new, "NEW", &mutex_new);
                // mostrar_cola(cola_ready, "READY", &mutex_ready);
                // mostrar_cola(cola_exec, "EXEC", &mutex_exec);
                // mostrar_cola(cola_blocked, "BLOCKED", &mutex_blocked);
                // mostrar_cola(cola_blocked_suspended, "BLOCKED SUSP", &mutex_blocked_suspended);
                // mostrar_cola(cola_suspended_ready, "SUSP READY", &mutex_suspended_ready);
                // mostrar_cola(cola_exit, "EXIT", &mutex_exit);
                                      
                log_info(logger, "Habilito planificador largo EXIT");
                sem_post(&sem_largo_plazo);  
                //despertar_planificador_largo_plazo();  
                log_info(logger, "Habilito planificador corto EXIT");    

                 
                sem_post(&proceso_en_ready);
                
                contador_de_exit += 1;

                break;
            }

            case MOTIVO_REPLANIFICAR: {
                log_info(logger, "_____________INTERRUPCION DE REPLANIFICACION_____________");
                log_info(logger, "[MANEJO CPU] Desalojo PID %d", pcb->pid);
                pcb->pc = devolucion.pc;
                if (strcmp(algoritmo_cola_ready, "SRT") == 0) {
                    pasar_a_ready_SRT(pcb, socket_interrupciones);
                } else {
                    pthread_mutex_lock(&mutex_ready);
                    queue_push(cola_ready, pcb);
                    pthread_mutex_unlock(&mutex_ready);



                if(!queue_is_empty(cola_new)){
                        mostrar_cola(cola_new, "NEW", &mutex_new);
                    }

                if(!queue_is_empty(cola_ready)){
                        mostrar_cola(cola_ready, "READY", &mutex_ready);
                    }

                if(!queue_is_empty(cola_exec)){
                    mostrar_cola(cola_exec, "EXEC", &mutex_exec);
                    }    
                    cambiar_estado(pcb, READY);
                    
                    log_info(logger, "Habilito planificador corto por REPLANIFICAR");
                    //sem_post(&proceso_en_ready);
                }

                break;
            }

            default: {
                log_warning(logger, "[MANEJO CPU] Motivo desconocido: %d", devolucion.motivo);
                break;
            }
        }

        if(contador_de_exit == contador_de_procesos){
            log_info(logger, "*******TERMINARON DE EJECUTAR TODOS LOS PROCESOS*******");
            log_info(logger, "Se ejecutaron y terminaron %d procesos", contador_de_exit);
            break;
        }
    }
    log_info(logger, "FIN ( ͡❛ ͜ʖ ͡❛) ʕ•́ᴥ•̀ʔっ （っ＾▿＾）");


    //log_info(logger, "\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀TUVE FE\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣤⣺⣉⣩⣧⣤⣦⣁⣭⣫⣲⣶⢄⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⣴⢚⣟⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣟⡶⢄⡀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⢀⣠⢜⣵⣿⣿⣿⣿⡿⠿⠿⠿⠿⣿⣿⣿⣿⣿⣿⣿⣿⣕⢥⡀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⢀⡮⣥⣾⣿⡿⠛⠉⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠛⠿⣿⣿⣿⣷⣽⢵⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⢸⣹⣿⡿⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⠀⠠⢉⠻⣿⣿⣿⣏⡇⠀⠀⠀⠀\n⠀⠀⠀⢠⣟⣿⠏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⢮⣿⣾⣷⡅⠙⣿⣿⣾⠀⠀⠀⠀\n⠀⠀⠀⢨⣻⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠁⢹⣳⣿⣿⣦⣿⣿⣾⡆⠀⠀⠀⠀\n⠀⠀⠀⢸⣿⡯⠀⠀⠀⢀⡀⡀⣀⠀⠀⠀⠀⠀⠀⢀⣀⣤⣴⣄⣌⠛⢻⣿⢿⣿⣿⡄⠀⠀⠀\n⠀⠀⠀⢸⣿⡿⢄⣠⣶⣿⡿⠿⢿⣿⣷⣆⠀⢸⣵⣿⣿⣿⠿⢿⣿⣷⣮⣯⣿⣿⢻⡆⠀⠀⠀\n⠀⠀⢀⣸⣿⡇⢉⣿⣿⣫⣴⣶⣶⣾⣿⣿⠀⠀⣿⣿⣿⣶⣶⣶⣿⣿⣿⣿⠿⡃⢸⠀⠀⠀⠀\n⠀⢰⣾⡉⢻⡈⠀⠘⠛⢿⣿⣿⠽⢏⠟⠀⠀⠀⢿⡿⡩⢭⣿⣿⣿⡿⠿⠿⢳⣀⣷⣦⠀\n⠀⢸⣿⡿⣴⡧⠀⠀⠀⠀⠀⠀⠀⠠⡠⠀⠀⠀⢠⢱⡄⠀⠀⠀⠀⠄⠀⠀⠱⣿⣿⣿⣿⡇⠀\n⠀⠈⣿⢰⣟⡇⠂⠀⠀⠀⠀⠀⢀⢴⢁⣠⣔⣢⣶⣧⣳⠀⠀⠀⠀⠀⡠⡔⠀⣿⣿⣿⣿⠀\n⠀⠀⣿⠖⢷⣿⢀⠀⠀⠐⠀⠠⠀⠘⢿⣿⣿⣿⣿⣿⣿⠄⠀⠀⢀⣾⣷⣿⢠⣿⣿⣿⠀\n⠀⠀⢓⣠⠌⣿⣖⣮⠏⠀⣀⣴⣶⣾⣿⣟⣿⣿⣿⣿⣿⣷⣦⣀⠳⣿⣿⣿⣼⣿⣿⠁⠀\n⠀⠀⠀⠱⢿⣿⣿⣿⣆⣸⣿⣿⣿⡿⠿⠿⠿⣿⠿⣿⣿⣿⣿⣿⣎⣿⣿⣿⣿⣿⠀⠀\n⠀⠀⠀⠀⠀⢿⣿⣿⣿⣿⣿⡟⠉⠒⣾⣿⣶⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢿⠁⠀⠀⠀\n⠀⠀⠀⠀⠀⠘⡽⣿⣿⣿⣿⣷⡄⠀⠘⡻⠿⠿⢿⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⢹⣿⣿⣿⣿⣿⣷⣾⣴⣢⣤⣶⣵⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣇⠀⠀⠀⠀⠀\n⠀⠀⠀⢀⡴⢹⠐⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠣⣀⠀⠀⠀\n⣤⣴⠞⠋⠀⢘⠉⣿⣿⣷⡿⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠙⢻⣶⡄");
    return NULL;
}

void* manejar_cpu_interrupciones(void* arg) {


    return NULL;
}

void* manejar_io(void* arg) {
    argumentos_io_t* args = (argumentos_io_t*)arg;

    int socket_io = args->socket_io;
    int socket_interrupciones = args->socket_interrupciones;

    char* algoritmo_planificacion = config_get_string_value(config, "ALGORITMO_CORTO_PLAZO"); 
    char* nombre_dispositivo = recibir_handshake_io(socket_io, logger);

    dispositivo_io_t* dispositivo = malloc(sizeof(dispositivo_io_t));
    dispositivo->nombre = nombre_dispositivo;
    dispositivo->socket_fd = socket_io;
    dispositivo->cola_bloqueados = queue_create();
    dispositivo->ocupado = false;
    pthread_mutex_init(&dispositivo->mutex, NULL);

    pthread_mutex_lock(&mutex_dispositivos_io);
    list_add(dispositivos_io, dispositivo);
    pthread_mutex_unlock(&mutex_dispositivos_io);

    log_info(logger, "[IO] Se conecto dispositivo: %s (fd=%d)", nombre_dispositivo, socket_io);

    while(1) {
        //enviar_request_io(pid, tiempo);
        
        int codigo;
        if (recv(socket_io, &codigo, sizeof(uint8_t), MSG_WAITALL) <= 0) {
            log_error(logger, "[IO] Error al recibir código de operación del dispositivo %s", nombre_dispositivo);
            break;
        }

        if (codigo != OPCODE_IO_FIN) {
            log_warning(logger, "[IO] Código de operación inesperado (%d) desde dispositivo %s", codigo, nombre_dispositivo);
            continue;
        }

        int pid;
        log_info(logger, "Esperamos recibir el PID");
        if (recv(socket_io, &pid, sizeof(int), MSG_WAITALL) <= 0) {
            log_error(logger, "[IO] Error al recibir PID desde el dispositivo %s", nombre_dispositivo);
            break;
        }

        log_info(logger, "## <%d> finalizo IO y pasa a READY", pid);
        log_info(logger, "Buscamos PCB del pid de la cola BLOCKED");


        //pcb_t* pcb = buscar_pcb_por_pid(pid);
        // pcb_t* pcb = encontrar_y_remover_pcb(pid);
        pcb_t* pcb = remover_pcb_de_cola(cola_blocked, &mutex_blocked, pid);

        if (pcb == NULL) {
            log_error(logger, "El PCB del PID %d que terminó I/O ya no existe. Probablemente ya finalizó.", pid);
            //En este caso seguimos y liberamos el dispositivo para no trabar el resto de procesos 
        }
        else{
            cambiar_estado(pcb, READY);
            pthread_mutex_lock(&mutex_ready);
            queue_push(cola_ready, pcb);
            pthread_mutex_unlock(&mutex_ready);

            log_info(logger, "Habilito planificador corto por manejar IO");
            sem_post(&proceso_en_ready);
            mostrar_cola(cola_ready, "READY", &mutex_ready);
        }


        // log_info(logger, "Cambiamos PID %d que estaba en pcb->%d a READY", pid, pcb->estado);

        pthread_mutex_lock(&dispositivo->mutex);      
        if(!queue_is_empty(dispositivo->cola_bloqueados)){      //OJO por que no usamos la cola_blocked????
            pcb_t* siguiente = queue_pop(dispositivo->cola_bloqueados);
            log_info(logger, "Dispositivo %s ahora ocupado por PID %d.", nombre_dispositivo, siguiente->pid);

            enviar_request_io(dispositivo, siguiente->pid, siguiente->tiempo_io);
            //cambiar_estado(siguiente, BLOCKED);

            log_info(logger, "## <%d> - DISPOSITIVO: %s - Bloqueado por IO -TIEMPO: %d", siguiente->pid, dispositivo->nombre, siguiente->tiempo_io);
        } 
        else {
            log_info(logger, "Dispositivo %s ahora está libre.", nombre_dispositivo);
            dispositivo->ocupado = false;
          
        }
        pthread_mutex_unlock(&dispositivo->mutex);

        // if (strcmp(algoritmo_planificacion, "SRT") == 0) {
        //     pasar_a_ready_SRT(pcb, socket_interrupciones); 
        // } 


        // mostrar_cola(cola_ready, "READY", &mutex_ready);
        // sem_post(&proceso_en_ready);

    }

    return NULL;
}

pcb_t* remover_pcb_de_cola(t_queue* cola, pthread_mutex_t* mutex, int pid) {
    pcb_t* pcb_encontrado = NULL;
    pthread_mutex_lock(mutex);

    // list_remove_by_condition es la forma más segura de hacer esto.
    bool _tiene_mismo_pid(void* pcb) {
        return ((pcb_t*)pcb)->pid == pid;
    }
    pcb_encontrado = list_remove_by_condition(cola->elements, _tiene_mismo_pid);

    pthread_mutex_unlock(mutex);
    return pcb_encontrado;
}

pcb_t* encontrar_y_remover_pcb(int pid) {
    pcb_t* pcb = NULL;

    if ((pcb = remover_pcb_de_cola(cola_new, &mutex_new, pid))) return pcb;
    if ((pcb = remover_pcb_de_cola(cola_ready, &mutex_ready, pid))) return pcb;
    if ((pcb = remover_pcb_de_cola(cola_exec, &mutex_exec, pid))) return pcb;

    if ((pcb = remover_pcb_de_cola(cola_blocked, &mutex_blocked, pid))) return pcb;
    
    // pthread_mutex_lock(&mutex_dispositivos_io);
    // for (int i = 0; i < list_size(dispositivos_io); i++) {
    //     dispositivo_io_t* dispositivo = list_get(dispositivos_io, i);
    //     if ((pcb = remover_pcb_de_cola(dispositivo->cola_bloqueados, &dispositivo->mutex, pid))) {
    //         pthread_mutex_unlock(&mutex_dispositivos_io);
    //         return pcb;
    //     }
    // }
    // pthread_mutex_unlock(&mutex_dispositivos_io);

    // Añade el resto de colas si es necesario (suspended, etc.)
    // ...

    log_warning(logger, "[find&remove] NO se encontró el pcb del proceso con pid %d en ninguna cola", pid);
    return NULL;
}

void enviar_request_io(dispositivo_io_t* dispositivo, int pid, int tiempo){
    //log_info(logger, "Se envia pid");
    send(dispositivo->socket_fd, &pid, sizeof(int), 0);

    send(dispositivo->socket_fd, &tiempo, sizeof(int), 0);
    //log_info(logger, "[IO] Enviada request a %s: PID: %d, Tiempo: %d", dispositivo->nombre, pid, tiempo);
}

pcb_t* buscar_en_cola(t_queue* cola, pthread_mutex_t* mutex, int pid) {
    pcb_t* encontrado = NULL;



    pthread_mutex_lock(mutex);

    int size = queue_size(cola);

    for (int i = 0; i < size; i++) {
        pcb_t* pcb = NULL;

        if (!queue_is_empty(cola)) {
            pcb = queue_pop(cola);

            if (pcb != NULL) {
                // log_info(logger, "en esta cola hay PID: %d", pcb->pid);

                if (!encontrado && pcb->pid == pid) {
                    encontrado = pcb;
                }

                queue_push(cola, pcb);
            }
        }
    }

    pthread_mutex_unlock(mutex);
    return encontrado;
}

pcb_t* buscar_pcb_por_pid(int pid) {
    pcb_t* encontrado = NULL;

    if ((encontrado = buscar_en_cola(cola_new, &mutex_new, pid)) != NULL) return encontrado;
    if ((encontrado = buscar_en_cola(cola_ready, &mutex_ready, pid)) != NULL) return encontrado;
    if ((encontrado = buscar_en_cola(cola_exec, &mutex_exec, pid)) != NULL) return encontrado;


    pthread_mutex_lock(&mutex_dispositivos_io);
    for (int i = 0; i < list_size(dispositivos_io); i++) {
        dispositivo_io_t* dispositivo = list_get(dispositivos_io, i);

        if ((encontrado = buscar_en_cola(dispositivo->cola_bloqueados, &dispositivo->mutex, pid)) != NULL) {
            pthread_mutex_unlock(&mutex_dispositivos_io);
            return encontrado;
        }
    }
    pthread_mutex_unlock(&mutex_dispositivos_io);

    if ((encontrado = buscar_en_cola(cola_blocked, &mutex_blocked, pid)) != NULL) return encontrado;
    if ((encontrado = buscar_en_cola(cola_blocked_suspended, &mutex_blocked_suspended, pid)) != NULL) return encontrado;
    if ((encontrado = buscar_en_cola(cola_suspended_ready, &mutex_suspended_ready, pid)) != NULL) return encontrado;
    if ((encontrado = buscar_en_cola(cola_exit, &mutex_exit, pid)) != NULL) return encontrado;

    log_info(logger, "NO encontre el pcb del proceso con pid %d", pid);
    //no lo encuentro mando null
    return NULL;
}

pcb_t* crear_proceso_pseudocodigo(char* archivo_pseudocodigo, int tamanio_proceso){

    if (archivo_pseudocodigo == NULL) {
        log_error(logger, "ERROR: archivo_pseudocodigo es NULL en crear_proceso_pseudocodigo");
        exit(EXIT_FAILURE);
    }

    pcb_t* pcb_proceso_nuevo = malloc(sizeof(pcb_t));
    pcb_proceso_nuevo->pid = generar_pid_unico();
    pcb_proceso_nuevo->tamanio = tamanio_proceso;
    pcb_proceso_nuevo->nombre_archivo = strdup(archivo_pseudocodigo);

    pcb_proceso_nuevo -> estado = NEW;
    pcb_proceso_nuevo -> pc = 0;
    
    //pcb_proceso_nuevo -> estimacion = 0.1;  // COMPLETAR!!! VALOR HARDCODEADO POR MI 
    pcb_proceso_nuevo -> estimacion = ESTIMACION_INICIAL;
    
    
    pcb_proceso_nuevo -> rafaga = 0;       

    pcb_proceso_nuevo -> cpu_asignada=NULL;

    pcb_proceso_nuevo -> ultima_actualizacion = 0;
    
    pcb_proceso_nuevo -> dispositivo_io = NULL;
    pcb_proceso_nuevo -> tiempo_io  = 0;

    for (int i = 0; i < 7; i++) { //inicio los temporizadores de cada estado y los pauso
        // e inicializo en cero la cantidad de veces q estuvieron en cada estado
        pcb_proceso_nuevo->metricas_estado[i] = 0;

        pcb_proceso_nuevo->temporizadores[i] = temporal_create();
        temporal_stop(pcb_proceso_nuevo->temporizadores[i]);
    }

    log_info(logger, "## (<%d>) Se crea el proceso - Archivo: %s - Tamaño: %d - Estado: NEW", pcb_proceso_nuevo->pid, archivo_pseudocodigo, pcb_proceso_nuevo->tamanio);
    
    
    
    return pcb_proceso_nuevo;
}

char* recv_param_string(int socket) {
    int longitud;

    //log_info(logger, "Esperando recibir longitud");
    if (recv(socket, &longitud, sizeof(int), MSG_WAITALL) <= 0) {
        perror("[recv_param_string] Error recibiendo longitud del string");
        exit(EXIT_FAILURE);
    }
    //log_info(logger, "Longitud recibida");

    char* buffer = malloc(longitud+1);    //OJO: al char* buffer = malloc(longitud + 1); le estoy sacando el +1 porque en un send ya me lo estan pasando el /0

    if (recv(socket, buffer, longitud, MSG_WAITALL) <= 0) {
        perror("[recv_param_string] Error recibiendo string");
        free(buffer);
        exit(EXIT_FAILURE);
    }
    

    buffer[longitud] = '\0';      //OJO +1    
    return buffer;
}

void recv_param_int(int socket, int* destino) {
    int bytes_recibidos = recv(socket, destino, sizeof(int), MSG_WAITALL);

    if (bytes_recibidos <= 0) {
        log_error(logger, "Error al recibir int");
        perror("recv");
        close(socket);
        exit(EXIT_FAILURE); // o retorná un código si no querés cortar el proceso
    }
}

void pasar_a_bloqueado(int pid, int socket_io) {

    // obtenemos el proceso en ejecución
    pthread_mutex_lock(&mutex_cpus);
    pcb_t* proceso = proceso_en_cpu;

    if (proceso == NULL || proceso->pid != pid) {
        pthread_mutex_unlock(&mutex_cpus);
        log_error(logger, "No se encontró el proceso en ejecución con PID %d", pid);
        return;
    }

    proceso_en_cpu = NULL;  // libero CPU
    pthread_mutex_unlock(&mutex_cpus);

    
    cambiar_estado(proceso, BLOCKED);

    // Enviamos al módulo IO
    log_info(logger, "[KERNEL] Enviando proceso PID %d al módulo IO por %d ms", pid, proceso->tiempo_io);
    //send(socket_io, &proceso->pid, sizeof(int), 0);
    //send(socket_io, &proceso->tiempo_io, sizeof(int), 0);

    // agregamos a la cola BLOCKED
    pthread_mutex_lock(&mutex_blocked);
    //log_info(logger, "pusheo 4");
    queue_push(cola_blocked, proceso);
    pthread_mutex_unlock(&mutex_blocked);
}

void* aceptar_ios(void* arg) {
    int servidor_io = *(int*)arg;
    free(arg);

    while(1) {
        log_info(logger, "[IO] Esperando conexion de IO...");
        int socket_io = esperar_cliente(servidor_io);

        if(socket_io == -1) {
            log_error(logger, "[IO] Error al aceptar conexion de IO");
            continue;
        }

        int* arg_socket_io = malloc(sizeof(int));
        *arg_socket_io = socket_io;

        pthread_t hilo_io;
        pthread_create(&hilo_io, NULL, manejar_io, arg_socket_io);
        pthread_detach(hilo_io);
    }

    return NULL;
}



void syscall_io(pcb_t* pcb, char* nombre_io, int tiempo){
    dispositivo_io_t* dispositivo = NULL;


    pthread_mutex_lock(&mutex_dispositivos_io);
    for(int i=0; i<list_size(dispositivos_io); i++){
        dispositivo_io_t* d = list_get(dispositivos_io, i);
        //log_info(logger, "Probamos con dispositivo %s, tiene que ser %s", d->nombre, nombre_io);
        if(strcmp(d->nombre, nombre_io) == 0) {
            dispositivo = d;
            break;
        }
    }

    pthread_mutex_unlock(&mutex_dispositivos_io);

    if(dispositivo == NULL){
        log_error(logger, "## <%d> - Dispositivo IO no encontrado: %s", pcb->pid, nombre_io);
        cambiar_estado(pcb, EXIT);
        finalizar_proceso(pcb, cola_new, cola_suspended_ready, pcb->nombre_archivo);

        log_info(logger, "Habilito planificador corto por SYSCALL IO");
        sem_post(&proceso_en_ready);
        return;
    }

    pcb->tiempo_io = tiempo;
    cambiar_estado(pcb, BLOCKED);

    pthread_mutex_lock(&mutex_blocked);
    queue_push(cola_blocked, pcb);
    pthread_mutex_unlock(&mutex_blocked);

    // queue_push(dispositivo->cola_bloqueados, pcb);
    log_info(logger, "## <%d> - Encolado en BLOCKED por IO: %s", pcb->pid, nombre_io);

    pthread_mutex_lock(&dispositivo->mutex);
    if(!dispositivo->ocupado){

        dispositivo->ocupado = true;
        log_info(logger, "## <%d> - Bloqueado por IO: %s", pcb->pid, nombre_io);
        enviar_request_io(dispositivo, pcb->pid, tiempo);
        
    } 
    else {
        queue_push(dispositivo->cola_bloqueados, pcb);
        //cambiar_estado(pcb, BLOCKED);
        log_info(logger, "## <%d> - Encolado en IO: %s", pcb->pid, nombre_io);
    }

    pthread_mutex_unlock(&dispositivo->mutex);
    //log_info(logger, "Termina syscall");

}



 
void queue_push_comienzo(t_queue* cola, pcb_t* pcb, pthread_mutex_t* mutex) {
    if (!cola || !pcb) {
        return; // No hacer nada si los punteros son nulos
    }

    pthread_mutex_lock(mutex);
    list_add_in_index(cola->elements, pcb, 0); // La clave es insertar en el índice 0
    pthread_mutex_unlock(mutex);
}