#include<utils/hello.h>
#include<planif_largo.h>
#include<pcb.h> 
#include<socket_kernel.h>
#include<planif_corto.h>


extern t_config* config;
extern t_log* logger;

extern sem_t sem_largo_plazo;
extern sem_t proceso_en_ready;

extern sem_t semaforo_proceso;


int socket_memoria;

bool flag_fin_un_proceso = false;

pthread_mutex_t mutex_pid = PTHREAD_MUTEX_INITIALIZER;

extern sem_t sem_conexion_kernel;


void cambiar_estado(pcb_t* pcb, estado_proceso_t nuevo_estado) {
    estado_proceso_t estado_anterior = pcb->estado;

    // Detener y guardar tiempo del estado anterior
    if (pcb->temporizadores[estado_anterior] != NULL) {
        temporal_stop(pcb->temporizadores[estado_anterior]);
        int64_t tiempo = temporal_gettime(pcb->temporizadores[estado_anterior]);
        pcb->metricas_tiempo[estado_anterior] += tiempo;
    }

    // Iniciar o reiniciar timer del nuevo estado
    if (pcb->temporizadores[nuevo_estado] == NULL) {
        pcb->temporizadores[nuevo_estado] = temporal_create();
    } 
    else {
        temporal_destroy(pcb->temporizadores[nuevo_estado]);
        pcb->temporizadores[nuevo_estado] = temporal_create();
    }
    // Actualizar métricas
    pcb->metricas_estado[nuevo_estado]++;
    pcb->estado = nuevo_estado;
}


void inicializar_planificador_largo_plazo(){
    
    pthread_t hilo_planificador_largo;
    pthread_create(&hilo_planificador_largo, NULL, planificador_largo_plazo, NULL);

    //pthread_join(hilo_planificador_largo, NULL);
    pthread_detach(hilo_planificador_largo);         
}



void* planificador_largo_plazo(void* args_void) {
    char* algoritmo_planificacion = config_get_string_value(config, "ALGORITMO_INGRESO_A_READY");
    char* puerto_memoria = config_get_string_value(config, "PUERTO_MEMORIA");
    char* ip = config_get_string_value(config, "IP_MEMORIA");

    log_info(logger, "Planificador de Largo Plazo iniciado.");

    while (1) {
        log_info(logger, "LARGO PLAZO: En esperando");
        sem_wait(&sem_largo_plazo);
        log_info(logger, "LARGO PLAZO: Despertado. Iniciando ciclo de admisión.");

        while (true) {
            
            
            pthread_mutex_lock(&mutex_new);
            if (queue_is_empty(cola_new)) {
                pthread_mutex_unlock(&mutex_new);
                log_info(logger, "LARGO PLAZO: Cola NEW vacia. Volviendo a esperar.");
                break; 
            }
            
            if (strcmp(algoritmo_planificacion, "SJF") == 0) {
                ordenar_cola_por_tamanio(cola_new);
            }
            
            pcb_t* proximo_proceso = queue_peek(cola_new);
            pthread_mutex_unlock(&mutex_new);

            if (proximo_proceso == NULL) {
                continue;
            }

            int socket_memoria = iniciar_kernel_cliente(ip, puerto_memoria);
            if (socket_memoria < 0) {
                log_error(logger, "Largo Plazo: No se pudo conectar a Memoria. Reintentando...");
                sleep(1);
                continue;
            }

            log_info(logger, "LARGO PLAZO Se intenta iniciar en memoria el -PID: %d", proximo_proceso->pid);
            bool memoria_acepto = enviar_inicio_a_memoria(proximo_proceso, socket_memoria, proximo_proceso->nombre_archivo);
            close(socket_memoria);
            

            if (memoria_acepto) {
                log_info(logger, "LARGO PLAZO Memoria aceptó al PID %d. Moviendo de NEW a READY.", proximo_proceso->pid);
                
                pthread_mutex_lock(&mutex_new);
                pcb_t* pcb_admitido = queue_pop(cola_new);
                pthread_mutex_unlock(&mutex_new);

                cambiar_estado(pcb_admitido, READY);
                pthread_mutex_lock(&mutex_ready);
                queue_push(cola_ready, pcb_admitido);
                pthread_mutex_unlock(&mutex_ready);

                mostrar_cola(cola_new, "NEW", &mutex_new);
                mostrar_cola(cola_ready, "READY", &mutex_ready);
                mostrar_cola(cola_exec, "EXEC", &mutex_exec);
                
                sem_post(&proceso_en_ready);
            } else {
                log_warning(logger, "Memoria rechazó al PID %d por falta de espacio. El Planificador de Largo Plazo detiene la admisión por ahora.", proximo_proceso->pid);
                break; 
            }
        } 
    }  
    
    return NULL; 
}



bool enviar_inicio_a_memoria(pcb_t* pcb, int socket_memoria, char* nombre_archivo) {
    
    int op = INIT_PROC;
    int pid = pcb->pid;
    int memoria = pcb->tamanio;
    
    //log_info(logger, "#### Se intenta iniciar en memoria el -PID: %d", pid);

    if (nombre_archivo == NULL) {
        log_error(logger, "ERROR: nombre_archivo es NULL al enviar a memoria");
        return false;
    }
    
    //_____envio datos de arranque a memoria________
    if (socket_memoria < 0) {
        log_error(logger, "No se pudo conectar a Memoria");
        return false;
    }

    if (send(socket_memoria, &op, sizeof(int), 0) != sizeof(int)) {
        perror("Error al enviar INIT_PROC");
        return false;
    }

    if (send(socket_memoria, &pid, sizeof(int), 0) != sizeof(int)) {
        perror("Error al enviar PID");
        return false;
    }

    uint32_t largo_nombre = strlen(nombre_archivo) + 1; // +1 por el '\0'
    if (send(socket_memoria, &largo_nombre, sizeof(uint32_t), 0) != sizeof(uint32_t)) {
        perror("Error al enviar largo del nombre de archivo");
        return false;
    }

    if (send(socket_memoria, nombre_archivo, largo_nombre, 0) != largo_nombre) {
        perror("Error al enviar nombre de archivo");
        return false;
    }

    if (send(socket_memoria, &memoria, sizeof(int), 0) != sizeof(int)) {
        perror("Error al enviar memoria solicitada");
        return false;
    }
    //_____________


    // Recibir respuesta
    //log_info(logger, "[PLanif largo] ");

    bool respuesta;
    if (recv(socket_memoria, &respuesta, sizeof(bool), MSG_WAITALL) != sizeof(bool)) {
        perror("Error al recibir respuesta de memoria");
        return false;
    }

    if (!respuesta) {
        log_warning(logger, "Memoria rechazó INIT_PROC para PID %d", pid);
        return false;
    }

    if(respuesta){
        t_list* lista_instrucciones = recibir_lista_instrucciones(socket_memoria);     

        if (lista_instrucciones == NULL || list_size(lista_instrucciones) <= 0) {
            log_error(logger, "Error: No se recibieron instrucciones válidas para el PID %d", pid);
            return NULL;
        }     
        
        // for (int i = 0; i < list_size(lista_instrucciones); i++) {
        //     log_info(logger, "Instrucción %d: %s", i, (char*)list_get(lista_instrucciones, i));
        // }

        list_destroy_and_destroy_elements(lista_instrucciones, free);
    }
    return respuesta;
}

int generar_pid_unico() {
    static int pid = 0;
    pthread_mutex_lock(&mutex_pid);
    int nuevo_pid = pid++;
    pthread_mutex_unlock(&mutex_pid);
    return nuevo_pid;
}

void log_metrica_estado(pcb_t* pcb) {

    log_info(logger, "## (%d) - Metricas de estado: NEW (%d) (%ldms), READY (%d) (%ldms), EXEC (%d) (%ldms)", 
             pcb->pid,
             pcb->metricas_estado[NEW], 
             pcb->metricas_tiempo[NEW], 

             pcb->metricas_estado[READY], 
             pcb->metricas_tiempo[READY], 

             pcb->metricas_estado[EXEC], 
             pcb->metricas_tiempo[EXEC]);          
}

void mover_a_estado(pcb_t* pcb, estado_proceso_t nuevo_estado) { 
    estado_proceso_t anterior = pcb->estado; 
    pcb->estado = nuevo_estado;
    long tiempo = pcb->metricas_tiempo[anterior - 1];    actualizar_metricas(pcb, anterior, tiempo);
    log_info(logger, "## (%d) Pasa del estado %d al estado %d",
             pcb->pid,
             anterior,
             nuevo_estado);         
}

bool comparar_por_tamanio(void* a, void* b) {
    pcb_t* pcb_a = (pcb_t*) a;
    pcb_t* pcb_b = (pcb_t*) b;

    return pcb_a->tamanio < pcb_b->tamanio;
}

void ordenar_cola_por_tamanio(t_queue* cola) {
        //ACA NO SE HACE NINGUN MUTEX OJOOOO!!!!!
    
        // saco todos los procesos de la cola y los pongo en una lista
        t_list* lista_temporal = list_create();

        while (!queue_is_empty(cola)) {

            pcb_t* proceso = queue_pop(cola);
            list_add(lista_temporal, proceso);
        }

        list_sort(lista_temporal, comparar_por_tamanio);    //ordeno en base al tamanio

        //arcmo la cola nueva con los procesos en la cola ordenada
        for (int i = 0; i < list_size(lista_temporal); i++) {
            pcb_t* proceso = list_get(lista_temporal, i);
            //log_info(logger, "pusheo 17");
            queue_push(cola, proceso);
        }

        list_destroy(lista_temporal); // No destruye elementos, solo la estructura
}

void actualizar_metricas(pcb_t* pcb, estado_proceso_t estado_anterior, long tiempo_actual) {
    // Calcular cuánto tiempo estuvo el proceso en el estado anterior
    long delta_t = tiempo_actual - pcb->ultima_actualizacion;

    // Sumar el tiempo al estado anterior
    if (estado_anterior >= NEW && estado_anterior <= EXIT) {
        pcb->metricas_tiempo[estado_anterior - 1] += delta_t;
    }

    // Sumar 1 vez que el proceso entra al nuevo estado (pcb->estado)
    if (pcb->estado >= NEW && pcb->estado <= EXIT) {
        pcb->metricas_estado[pcb->estado - 1] += 1;
    }

    // Actualizar el tiempo de última actualización para el próximo cálculo
    pcb->ultima_actualizacion = tiempo_actual;
}



void finalizar_proceso(pcb_t* pcb, t_queue* cola_new, t_queue* cola_suspended_ready, char* nombre_archivo) {
    char* puerto_memoria = config_get_string_value(config, "PUERTO_MEMORIA");
    char* ip = config_get_string_value(config, "IP_MEMORIA");

    int conexion_memoria = iniciar_kernel_cliente(ip, puerto_memoria);
    if (conexion_memoria < 0) {
        log_error(logger, "[Finalizar] No se pudo conectar a Memoria para finalizar PID %d", pcb->pid);
        // A pesar del error de conexión, debemos continuar para liberar el PCB.
    } else {
        log_info(logger, "Enviamos EXIT_PROC a memoria PID: %d", pcb->pid);
        enviar_codigo_operacion(EXIT_PROC, conexion_memoria);
        send(conexion_memoria, &pcb->pid, sizeof(int), 0); // OJO: sizeof(int), no sizeof(pcb->pid)
        
        int respuesta = recibir_operacion(conexion_memoria);
        if (respuesta != MEM_OK) {
            log_warning(logger, "[Finalizar] Memoria no pudo confirmar el EXIT_PROC para PID %d. Respuesta: %d", pcb->pid, respuesta);
        }
        close(conexion_memoria);
    }

    log_info(logger, "## (%d) - Finaliza el proceso", pcb->pid);
    cambiar_estado(pcb, EXIT);
    log_metrica_estado(pcb);

    // Libera recursos del PCB
    if (pcb->cpu_asignada != NULL) {
        pthread_mutex_lock(&mutex_cpus);
        pcb->cpu_asignada->disponible = true;
        pcb->cpu_asignada->proceso_actual = NULL;
        pcb->cpu_asignada = NULL;
        pthread_mutex_unlock(&mutex_cpus);
    }

    log_info(logger, "liberamos pcb PID: %d", pcb->pid);
    free(pcb->nombre_archivo);
    free(pcb);
    
    // La bandera flag_fin_un_proceso ya no es necesaria con la nueva lógica del PLP.
}

// void finalizar_proceso(pcb_t* pcb, t_queue* cola_new, t_queue* cola_suspended_ready, char* nombre_archivo) {
//     char* puerto_memoria = config_get_string_value(config, "PUERTO_MEMORIA");
//     char* ip = config_get_string_value(config, "IP_MEMORIA");
//     char* algoritmo_planificacion = config_get_string_value(config, "ALGORITMO_INGRESO_A_READY");

//     log_info(logger, "[KERNEL] Inicio conexión efímera a Memoria. PID: %d", pcb->pid);

//     int conexion_memoria = iniciar_kernel_cliente(ip, puerto_memoria);

//     log_info(logger, "Enviamos EXIT_PROC a memoria PID: %d", pcb->pid);
    
    
//     enviar_codigo_operacion(EXIT_PROC, conexion_memoria);
//     send(conexion_memoria, &pcb->pid, sizeof(pcb->pid), 0);

//     log_info(logger, "Enviamos memoria PID: %d", pcb->pid);
//     log_info(logger, "PID enviado: %d", pcb->pid);

    
//     int respuesta = recibir_operacion(conexion_memoria);
//     //int respuesta = recibir_operacion(conexion_memoria);
    
//     if (respuesta == -1) {
//         log_error(logger, "Fallo en recv (posible cierre prematuro de Memoria)");
//     }

//     log_info(logger, "$$$$CIERRO CONEXION MEMORIA$$$$");
//     close(conexion_memoria);

//     log_info(logger, "MEMORIA ME DIJO %d", respuesta);
//     if (respuesta != MEM_OK) {
//         log_error(logger, "[KERNEL] Memoria rechazó el EXIT_PROC para PID %d", pcb->pid);
//         return;
//     }

//     log_info(logger, "## (%d) - Finaliza el proceso", pcb->pid);

//     cambiar_estado(pcb, EXIT);
//     log_metrica_estado(pcb);

//     // Intento pasar de SUSPENDED_READY a READY

//     pthread_mutex_lock(&mutex_suspended_ready);
//     while (!queue_is_empty(cola_suspended_ready)) {
//         pcb_t* proceso = queue_pop(cola_suspended_ready);
//         int socket = iniciar_kernel_cliente(ip, puerto_memoria);

//         if (enviar_desuspender_a_memoria(proceso, socket)) {
//             close(socket);
//             cambiar_estado(proceso, READY);
//             pthread_mutex_lock(&mutex_ready);
//             queue_push(cola_ready, proceso);
//             pthread_mutex_unlock(&mutex_ready);
//             log_info(logger, "Habilito planificador corto desde finalizar_proceso");
//             sem_post(&proceso_en_ready);
//             log_info(logger, "Cambio de Estado: PID %d pasa de SUSPENDED_READY a READY", proceso->pid);
//         } else {
//             close(socket);
//             break;
//         }
//     }
//     pthread_mutex_unlock(&mutex_suspended_ready);

//     // Intento pasar de NEW a READY
    
//     if (queue_is_empty(cola_suspended_ready) && !queue_is_empty(cola_new)) {
//         if (strcmp(algoritmo_planificacion, "FIFO") == 0) {
//             pcb_t* proceso = queue_peek(cola_new);

//             log_info(logger, "[KERNEL] Inicio conexión efímera a Memoria. PID: %d", proceso->pid);

//             int socket = iniciar_kernel_cliente(ip, puerto_memoria);
//             if (enviar_inicio_a_memoria(proceso, socket, proceso->nombre_archivo)) {
//                 pthread_mutex_lock(&mutex_new);
//                 queue_pop(cola_new);
//                 pthread_mutex_unlock(&mutex_new);
//                 close(socket);

//                 cambiar_estado(proceso, READY);
//                 pthread_mutex_lock(&mutex_ready);
//                 queue_push(cola_ready, proceso);
//                 pthread_mutex_unlock(&mutex_ready);
//                 log_info(logger, "Habilito planificador corto desde finalizar_proceso");
//                 sem_post(&proceso_en_ready);
//                 log_info(logger, "Cambio de Estado: PID %d pasa de NEW a READY", proceso->pid);
//             } else {
//                 close(socket);
//             }

//         } else if (strcmp(algoritmo_planificacion, "SJF") == 0) {
//             pthread_mutex_lock(&mutex_new);
//             ordenar_cola_por_tamanio(cola_new);
//             pthread_mutex_unlock(&mutex_new);

//             while (!queue_is_empty(cola_new)) {
//                 pcb_t* proceso = queue_peek(cola_new);
        
//                 log_info(logger, "[KERNEL] Inicio conexión efímera a Memoria. PID: %d", proceso ->pid);

//                 int socket = iniciar_kernel_cliente(ip, puerto_memoria);
//                 if (enviar_inicio_a_memoria(proceso, socket, proceso->nombre_archivo)) {
//                     pthread_mutex_lock(&mutex_new);
//                     queue_pop(cola_new);
//                     pthread_mutex_unlock(&mutex_new);
//                     close(socket);

//                     cambiar_estado(proceso, READY);
//                     pthread_mutex_lock(&mutex_ready);
//                     queue_push(cola_ready, proceso);
//                     pthread_mutex_unlock(&mutex_ready);

//                     log_info(logger, "Habilito planificador corto desde finalizar proceso");
//                     sem_post(&proceso_en_ready);
//                     log_info(logger, "Cambio de Estado: PID %d pasa de NEW a READY", proceso->pid);
//                 } else {
//                     close(socket);
//                     break;
//                 }
//             }
//         }
//     }

//     // Libera recursos del proceso finalizado
//     if (pcb->cpu_asignada != NULL) {
//         pthread_mutex_lock(&mutex_cpus);
//         pcb->cpu_asignada->disponible = true;
//         pcb->cpu_asignada->proceso_actual = NULL;
//         pcb->cpu_asignada = NULL;
//         pthread_mutex_unlock(&mutex_cpus);
//     }


//     log_info(logger, "liberamos pcb PID: %d", pcb->pid);
//     free(pcb->nombre_archivo);
//     free(pcb);
//     //log_info(logger, "pcb liberada PID: %d", pcb->pid);
//     flag_fin_un_proceso = true;
// }



bool enviar_desuspender_a_memoria(pcb_t* proceso, int conexion_memoria) {
    int cod_op = DESUSPENDER_PROC;

    enviar_codigo_operacion(cod_op, conexion_memoria);

    int respuesta = recibir_operacion(conexion_memoria);

    if (respuesta == MEM_OK) {
        return true;
    } else {
        return false;
    }
}

t_list* recibir_lista_instrucciones(int socket_memoria) {
    int cantidad;
    if (recv(socket_memoria, &cantidad, sizeof(int), MSG_WAITALL) != sizeof(int)) {
        perror("Error al recibir cantidad");        //COMPLETAR!!!! SALTA ESTE ERROR EN TERMINAL
        return NULL;                                //Cuando inicio kernel como proceso1.txt 256    salta este error!!! el tamanio q elijo lo afecta por algun motivo
    }

    t_list* lista = list_create();
    for (int i = 0; i < cantidad; i++) {
        int len;
        if (recv(socket_memoria, &len, sizeof(int), MSG_WAITALL) != sizeof(int)) {
            perror("Error al recibir longitud");
            list_destroy(lista);
            return NULL;
        }

        char* buffer = malloc(len);
        if (recv(socket_memoria, buffer, len, MSG_WAITALL) != len) {
            perror("Error al recibir instrucción");
            free(buffer);
            list_destroy(lista);
            return NULL;
        }

        list_add(lista, buffer);
    }

    return lista;
}