#include <utils/hello.h>

#define OPCODE_HANDSHAKE_IO 1
#define OPCODE_IO_REQUEST   2
#define OPCODE_IO_FIN       3

typedef struct t_io_request {
    int pid;
    int tiempo;
} t_io_request;

t_io_request* recibir_io_request(int socket_kernel);
void enviar_finalizacion_io(int , int );

int iniciar_cliente(const char* , const char* );
