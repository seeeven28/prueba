#include<mem_largo_plazo.h>
#include<socket_mem.h>
#include<mem.h>
#include <metricas.h>
#include <math.h>


extern t_config* config;
extern t_log* logger;
extern t_dictionary* pseudocodigos;
t_list* procesos_en_memoria; 
FILE* swapfile;
pthread_mutex_t proceso_en_memoria_mutex;

extern int cantidad_niveles_tablas;
extern int TAM_PAGINA;

extern sem_t sem_conexion_kernel;


extern void* espacio_usuario;
//#define MAX_MARCOS 128                          //COMPLETAR, ESTE VALOR DEBE SER CALCULADO SEGUN EL TAM_MEMORIA -> TAM_MEMORIA / TAM_PAGINA     DIVISION ENTERA!!!
extern int MAX_MARCOS;
//bool marcos_usados[MAX_MARCOS] = { false };     //Este es el bit de marcos libres. MAX_USADOS representa la cantidad de marcos en el sistema
extern bool* marcos_usados;

void* atender_conexion_kernel(void* arg) {
    sem_wait(&sem_conexion_kernel);

    int socket_cliente = *(int*)arg;
    free(arg);

    int operacion;
    int pid;
    int memoria_solicitada;
    char* nombre_archivo;
    bool okay;
    //bool ok;
    int niveles = config_get_int_value(config, "CANTIDAD_NIVELES");
    int entradas_por_tabla = config_get_int_value(config, "ENTRADAS_POR_TABLA");


    log_info(logger, "vamos a recibir la operacion del kernel");
    if (recv(socket_cliente, &operacion, sizeof(int), MSG_WAITALL) <= 0) {
        close(socket_cliente);
        return NULL;
    }


    log_info(logger, "operacion RECIBIDA: %d", operacion);
    log_info(logger, "[ATENDER_KERNEL] Hilo nuevo. PID del hilo: %lu", pthread_self());

    switch (operacion) {

        case INIT_PROC: {
            log_info(logger, "_____________INIT PROC EN MEMORIA_____________");
            if (recv(socket_cliente, &pid, sizeof(int), MSG_WAITALL) <= 0) {
                close(socket_cliente);
                return NULL;
            }

            uint32_t largo_nombre;
            if (recv(socket_cliente, &largo_nombre, sizeof(uint32_t), MSG_WAITALL) <= 0) {
                close(socket_cliente);
                return NULL;
            }

            nombre_archivo = malloc(largo_nombre + 1);
            if (recv(socket_cliente, nombre_archivo, largo_nombre, MSG_WAITALL) <= 0) {
                free(nombre_archivo);
                close(socket_cliente);
                return NULL;
            }

            if (recv(socket_cliente, &memoria_solicitada, sizeof(int), MSG_WAITALL) <= 0) {
                free(nombre_archivo);
                close(socket_cliente);
                return NULL;
            }

            

            int memoria_total = contar_marcos_libres() * TAM_PAGINA;
            okay = (memoria_solicitada <= memoria_total);

            send(socket_cliente, &okay, sizeof(bool), 0);

            if (!okay) {
                log_warning(logger, "Memoria rechazo al proceso por falta de espacio");
                free(nombre_archivo);
                break;
            }

            // Leer instrucciones
            t_list* instrucciones = leer_instrucciones_de_archivo(nombre_archivo);
            if (!instrucciones || list_size(instrucciones) == 0) {
                log_error(logger, "Error al leer archivo %s", nombre_archivo);
                free(nombre_archivo);
                break;
            }

            log_info(logger, "PID: %d, Archivo: %s, Memoria: %d", pid, nombre_archivo, memoria_solicitada);
            
            int tamanio_instrucciones = list_size(instrucciones);
            int paginas_instrucciones = (tamanio_instrucciones + entradas_por_tabla - 1) / entradas_por_tabla;
            

            int paginas_datos = (memoria_solicitada + TAM_PAGINA - 1) / TAM_PAGINA;
            
            proceso_memoria_t* nuevo = malloc(sizeof(proceso_memoria_t));
            nuevo->pid = pid;
            nuevo->cantidad_paginas = paginas_instrucciones + paginas_datos;


            nuevo->tabla_primer_nivel = malloc(sizeof(tabla_paginas_t));
            nuevo->tabla_primer_nivel->id = 0;
            nuevo->tabla_primer_nivel->entradas = list_create();
            nuevo->tabla_primer_nivel->nivel = 0;

            nuevo -> tabla_primer_nivel -> pid =nuevo->pid; //OJO se puede sacar el hecho de que la tabla guarde PID. lo hago para seguir el proceso

            log_info(logger, "cant instrucciones: %d", tamanio_instrucciones);
            log_info(logger, "paginas para instruccines: %d instrucciones", paginas_instrucciones);
            log_info(logger, "paginas para guardar datos: %d", paginas_datos);
            log_info(logger, "cantidad de paginas del proceso: %d", nuevo->cantidad_paginas);

            int paginas_restantes = nuevo->cantidad_paginas;
            crear_tablas_recursivo(nuevo->tabla_primer_nivel, niveles, entradas_por_tabla, &paginas_restantes);
            log_info(logger, "Estructura de tablas del PID %d:", nuevo->pid);
            
            //imprimir_tablas_pagina(nuevo->tabla_primer_nivel, niveles, entradas_por_tabla);
            
            
            int pagina_logica_actual = 0;
            imprimir_tablas_pagina(nuevo->tabla_primer_nivel, niveles, entradas_por_tabla, &pagina_logica_actual, paginas_instrucciones, instrucciones);

        
            pthread_mutex_lock(&proceso_en_memoria_mutex);
            list_add(procesos_en_memoria, nuevo);
            pthread_mutex_unlock(&proceso_en_memoria_mutex);

            char* pid_str = string_itoa(pid);

            dictionary_put(pseudocodigos, pid_str, instrucciones);  //ASIGNA INSTRUCCIONES AL PID: diccionario pseudocodigos, pid como key e instr como elementos

            enviar_lista_instrucciones(socket_cliente, instrucciones);
            agregar_metrica(pid);

            log_info(logger, "[MEMORIA] Proceso %d creado con %d páginas totales", pid, nuevo->cantidad_paginas);
            
            free(nombre_archivo);

            //close(socket_cliente);
            break;
        }



        case SUSPENDER_PROC:
            log_info(logger, "_____________SUSP PROC EN MEMORIA_____________");
            recv(socket_cliente, &pid, sizeof(int), MSG_WAITALL);
            bool bien = suspender_a_swap(pid);
            if(bien){
                enviar_codigo_operacion(MEM_SWAP_OK, socket_cliente);
            } else {
                enviar_codigo_operacion(MEM_SWAP_ERR, socket_cliente);
            }
            break;
        
        
        
        case DESUSPENDER_PROC:
            log_info(logger, "_____________DESUSP PROC EN MEMORIA_____________");
            log_info(logger, "Esperando recibir pid DESUSPENDER PROC");
            if(recv(socket_cliente, &pid, sizeof(int), MSG_WAITALL)){
                close(socket_cliente);
            }
            log_info(logger, "pid RECIBIDO");

            //bool ok = desuspender_proceso(pid);
            //ok=true;    //COMPLETAR!!! HARDCODEO ok = true HASTA QUE SE HAGA EL SWAP PARA LA FUNCION

            bool ok = desuspender_de_swap(pid);

            if (ok) {
                enviar_codigo_operacion(MEM_OK, socket_cliente);
            }
            else {
                enviar_codigo_operacion(MEM_ERROR, socket_cliente);
            }
            break;
        

        case EXIT_PROC: {
            log_info(logger, "_____________EXIT PROC EN MEMORIA_____________");
            log_info(logger, "EXIT_PROC MEMORIA esperando recibir PID");


            log_info(logger, "Esperamos recibir PID");

            // if (recv(socket_cliente, &pid, sizeof(int), MSG_WAITALL) <= 0) {
            //     log_error(logger, "Fallo al recibir PID en EXIT_PROC");
            //     close(socket_cliente);
            //     return NULL;
            // }

            if(socket_cliente != NULL){
                log_info(logger, "El socket esta activo %d", socket_cliente);
            }


            log_info(logger, "esperamos recibir PID");
            int resultado = recv(socket_cliente, &pid, sizeof(int), MSG_WAITALL);   //HAGO MSG WAITALL Y CAMBIA
            if (resultado <= 0) {
                log_error(logger, "Error al recibir PID. recv() devolvió %d", resultado);
                close(socket_cliente);
                pthread_exit(NULL);
            }
            log_info(logger, "EXIT_PROC recibe PID: %d", pid);


            // Informar a memoria que el proceso finalizó y liberar recursos
            log_info(logger, "Ejecutamo finalizar_proceso_en_memoria");
            bool ok = finalizar_proceso_en_memoria(pid);

            if (ok) {
                enviar_codigo_operacion(MEM_OK, socket_cliente);
                log_info(logger, "MEM OK enviado al Kernel");
            } else {
                enviar_codigo_operacion(MEM_ERROR, socket_cliente);
                log_info(logger, "MEM ERROR enviado al Kernel");
            }

            // Ya no accedemos a p->tabla_paginas porque usamos jerarquía
            // Eliminar swap e imprimir métricas ya está incluido en finalizar_proceso_en_memoria
            log_info(logger, "RECIBIDO EXIT_PROC. Proceso ha salido. PID: %d", pid);
            
            break;
        }
    

        default:
            log_error(logger, "Operacion desconocida: %d", operacion);
            break;
    }
    //sleep(10);
    log_info(logger, "XXXXXXXXX_______XXXXXXXXXXXXXXX_______________XXXXXXXXXX CERRANDO CONEXION DE KERNEL__________");
    //close(socket_cliente);
    
    shutdown(socket_cliente, SHUT_WR);
    sleep(1);  // Dar tiempo al cliente para cerrar
    close(socket_cliente);
    
    sem_post(&sem_conexion_kernel);

    return NULL;
}

t_list* leer_instrucciones_de_archivo(char* nombre_archivo) {
    char* path_base = config_get_string_value(config, "PATH_INSTRUCCIONES");

    char nombre_completo[256];

    // Verificamos si ya tiene la extensión .txt
    if (string_ends_with(nombre_archivo, ".txt")) {
        strcpy(nombre_completo, nombre_archivo);
    } else {
        sprintf(nombre_completo, "%s.txt", nombre_archivo);
    }

    char path_completo[512];
    sprintf(path_completo, "%s/%s", path_base, nombre_completo);

    log_info(logger, "Intentando abrir archivo: %s", path_completo);    

    FILE* f = fopen(path_completo, "r");
    if (!f) {
        log_error(logger, "No se pudo abrir el archivo: %s", path_completo);
        return NULL;
    }

    t_list* instrucciones = list_create();
    char* linea = NULL;
    size_t len = 0;

    while (getline(&linea, &len, f) != -1) {
        char* copia_linea = string_duplicate(linea);
        string_trim_right(&copia_linea);
        list_add(instrucciones, copia_linea);
    }

    fclose(f);
    free(linea);
    return instrucciones;
}

void* atender_conexion_cpu(void* arg) { 

    int socket_cliente = *(int*)arg;
    free(arg);

    int pid_actual_cpu = -1;

    while (1) {
        int cod_op;


        log_info(logger, "Esperando recibir codigo de operacion desde la CPU");
        if (recv(socket_cliente, &cod_op, sizeof(int), MSG_WAITALL) <= 0) {
            log_info(logger, "[MEMORIA] CPU desconectada.");
            close(socket_cliente);
            return NULL;
        }

        switch (cod_op) {  

            case PEDIR_INSTRUCCION: {
                log_info(logger, "_____________PEDIDO DE INSTRUCCION_____________");
                log_info(logger,"Recibi codigo de la CPU: PEDIR INSTRUCCION");
                int pid;
                int marco;
                int offset;
                
                // send(socket, &TAM_PAGINA, sizeof(int), 0);
                // send(socket, &entradas_por_pagina, sizeof(int);
                // send(socket, &cantidad_niveles_tablas, sizeof(int), 0);

                // int nivel_actual;

                // send(socket, &nivel_actual, sizeof(int), 0) <= 0);

                recv(socket_cliente, &pid, sizeof(int), MSG_WAITALL);
                recv(socket_cliente, &marco, sizeof(int), MSG_WAITALL);
                recv(socket_cliente, &offset, sizeof(int), MSG_WAITALL);

                // pthread_mutex_lock(&mutex_entradas_por_pagina);
                // recv(socket_cliente, &entradas_por_pagina, sizeof(int), MSG_WAITALL);
                // pthread_mutex_unlock(&mutex_entradas_por_pagina);
                
                
                // El pc lo calculamos despues
                // ahora usamos marco+offset como referencia

                //int pid_actual_cpu = pid; OJO variable no utilizada

                // buscamos la instrucción usando el diccionario
                char* pid_str = string_itoa(pid);
                t_list* instrucciones = dictionary_get(pseudocodigos, pid_str);
                //free(pid_str);

                if (!instrucciones) {
                    log_error(logger, "No se encontraron instrucciones para PID %d", pid);
                    enviar_param_string(socket_cliente, "ERROR");
                    break;
                }

                int pc = marco * entradas_por_pagina + offset;


                // log_info(logger, "CALCULE PC   ))))))))))))))))))))))))))))))%d", pc);
                // log_info(logger, "RECIBI MARCO ))))))))))))))))))))))))))))))%d", marco);

                if (pc >= list_size(instrucciones)) {
                    log_error(logger, "PC %d fuera de rango para PID %d", pc, pid);
                    enviar_param_string(socket_cliente, "EXIT");
                    break;
                }

                if (pc >= list_size(dictionary_get(pseudocodigos, string_itoa(pid)))) {
                    log_warning(logger, "PID %d intentó acceder a PC %d que está fuera del rango de instrucciones", pid, pc);
                    enviar_param_string(socket_cliente, "EXIT");
                    //return;
                }


                char* instruccion = list_get(instrucciones, pc);
                log_info(logger, "[MEMORIA] Enviando instrucción PID %d - PC %d: %s", pid, pc, instruccion);
                enviar_param_string(socket_cliente, instruccion);
                obtener_metricas(pid)->instrucciones_solicitadas++;
                break;
            }

            case SOLICITAR_PAGINA: {
                log_info(logger, "_____________SE SOLICITO PAGINA_____________");
                log_info(logger,"Recibi codigo de la CPU: SOLICITAR_PAGINA");
                int pid, pagina;

                if (recv(socket_cliente, &pid, sizeof(int), MSG_WAITALL) <= 0 ||
                    recv(socket_cliente, &pagina, sizeof(int), MSG_WAITALL) <= 0) {
                    log_error(logger, "[MEMORIA] Error al recibir datos de CPU en SOLICITAR_PAGINA");
                    close(socket_cliente);
                    return NULL;
                }

                // Leer contenido real desde memoria
                char* contenido = leer_pagina_de_memoria(pid, pagina);

                if (contenido == NULL) {
                    log_warning(logger, "[MEMORIA] Se devolvió contenido vacío para PID %d - Página %d", pid, pagina);
                    contenido = strdup("");  // por las dudas nunca mandamos NULL
                }

                // Enviamos a la CPU
                enviar_param_string(socket_cliente, contenido);

                log_info(logger, "[MEMORIA] Página enviada a CPU - PID %d - Página %d - Contenido: '%s'",
                        pid, pagina, contenido);

                free(contenido); // importantísimo para evitar memory leaks
                break;
            }

            case ESCRIBIR_PAGINA: {
                log_info(logger, "_____________PEDIDO DE ESCRITURA_____________");
                
                int pid, pagina, largo_contenido;
                //log_info(logger, "Esperando recibir pid, pagina, largo contenido, nuevo contenido");
                recv(socket_cliente, &pid, sizeof(int), MSG_WAITALL);
                recv(socket_cliente, &pagina, sizeof(int), MSG_WAITALL);
                recv(socket_cliente, &largo_contenido, sizeof(int), MSG_WAITALL);

                char* nuevo_contenido = malloc(largo_contenido);
                recv(socket_cliente, nuevo_contenido, largo_contenido, MSG_WAITALL);
                //log_info(logger, "pid, pagina, largo contenido y nuevo contenido RECIBIDO");

                log_info(logger, "[MEMORIA] PID %d - Escribiendo contenido en página %d", pid, pagina);

            
                actualizar_contenido_pagina(pid, pagina, nuevo_contenido);  

                free(nuevo_contenido);
                break;
            }

            case INSTR_READ: {
                log_info(logger, "_____________PEDIDO DE LECTURA_____________");
                char* direccion_str = recv_param_string(socket_cliente);
                int tamanio;           
                recv_param_int(socket_cliente,&tamanio);
                int entradas_por_pagina;

                //pthread_mutex_lock(&mutex_entradas_por_pagina);
                recv(socket_cliente, &entradas_por_pagina, sizeof(int), MSG_WAITALL);   
                //pthread_mutex_unlock(&mutex_entradas_por_pagina);

                int direccion = atoi(direccion_str);
                int pagina = direccion / entradas_por_pagina;
                int offset = direccion % entradas_por_pagina;

                log_info(logger, "[MEMORIA] READ - PID: %d - Pagina: %d - Offset: %d - Tamaño: %d", pid_actual_cpu, pagina, offset, tamanio);

                char* contenido = leer_pagina_de_memoria(pid_actual_cpu, pagina);

                // Validación de límite para evitar overflows
                if (offset + tamanio > TAM_PAGINA) {
                    int tamanio_pagina = TAM_PAGINA;    //solo la uso para el log de abajo, nunca mas
                    log_warning(logger, "[MEMORIA] READ excede el tamaño de página. Ajustando tamaño a %d", tamanio_pagina - offset);
                    tamanio = tamanio_pagina - offset;
                }

                send(socket_cliente, contenido + offset, tamanio, 0);

                free(direccion_str);
                free(contenido);
                break;
            }


            case SOLICITAR_MARCO: {
                
                log_info(logger, "_____________PEDIDO DE MARCO_____________");
                int pid, pagina;
                recv(socket_cliente, &pid, sizeof(int), MSG_WAITALL);
                recv(socket_cliente, &pagina, sizeof(int), MSG_WAITALL);

                log_info(logger, "Buscamos proceso a traves de su PID en las tablas");
                proceso_memoria_t* proceso = buscar_proceso(pid);

                log_info(logger, "PROCESO %d", proceso->pid);

                log_info(logger, "Buscamos proceso entrada");
                entrada_tabla_pagina_t* entrada = obtener_entrada(proceso, pagina);

                log_info(logger, "[MEMORIA] Entrada: marco=%d, presente=%d, modificado=%d, usado=%d",
                entrada->marco,
                entrada->presente,
                entrada->modificado,
                entrada->usado);


                if (!entrada || !entrada->presente) {
                    int marco_invalido = -1;
                    send(socket_cliente, &marco_invalido, sizeof(int), 0);
                    break;
                }

                if (pagina >= proceso->cantidad_paginas) {
                    log_error(logger, "[MEMORIA] Página lógica fuera de rango para PID %d: %d >= %d", pid, pagina, proceso->cantidad_paginas);
                    int marco_invalido = -1;
                    send(socket_cliente, &marco_invalido, sizeof(int), 0);
                    break;
                }


                send(socket_cliente, &entrada->marco, sizeof(int), 0);
                log_info(logger, "Se le dio el marco: %d", entrada->marco);
                obtener_metricas(pid)->accesos_tablas_paginas += config_get_int_value(config, "CANTIDAD_NIVELES");
                break;
            }


            default:
                log_warning(logger, "[MEMORIA] Código de operación desconocido: %d", cod_op);
                break;
        }
    }

    return NULL;
}

// void actualizar_contenido_pagina(int pid, int pagina, const char* contenido) {  //funcion que usamos cuando la CPU quiere escribir
//     if (contenido == NULL) {
//         log_error(logger, "[MEMORIA] Contenido NULL recibido para PID %d, página %d", pid, pagina);
//         return;
//     }
//     proceso_memoria_t* proceso = buscar_proceso(pid); // buscás en la lista
//     if (proceso == NULL || pagina >= proceso->cantidad_paginas || pagina < 0) {
//         log_error(logger, "[MEMORIA] Error al escribir: Proceso %d o página %d inválida", pid, pagina);
//         return;
//     }
// }
//REEMPLAZO actualizar_contenido_pagina POR:


void actualizar_contenido_pagina(int pid, int pagina, const char* contenido) {
    proceso_memoria_t* p = buscar_proceso(pid);
    if (!p) return;

    entrada_tabla_pagina_t* entrada = obtener_entrada(p, pagina);
    if (!entrada || !entrada->presente) return;

    int marco = entrada->marco;
    void* destino = espacio_usuario + marco * TAM_PAGINA;
    memcpy(destino, contenido, TAM_PAGINA);
    entrada->modificado = true;
    obtener_metricas(pid)->escrituras++;
}


// char* leer_pagina_de_memoria(int pid, int pagina) {     //esta la usamos cuando CPU pide Leer
//     proceso_memoria_t* proceso = buscar_proceso(pid);
//     if (proceso == NULL || pagina >= proceso->cantidad_paginas || pagina < 0) {
//         log_error(logger, "[MEMORIA] Error al leer: Proceso %d o página %d inválida", pid, pagina);
//         return strdup(""); // Devuelve vacío por seguridad
//     }
// }
//REEMPLAZO LEER PAGINA DE MEMORIA POR ESTA VERSION:
char* leer_pagina_de_memoria(int pid, int pagina) {
    proceso_memoria_t* p = buscar_proceso(pid);
    entrada_tabla_pagina_t* entrada = obtener_entrada(p, pagina);

    if (!entrada || !entrada->presente) {
        log_warning(logger, "[MEMORIA] Página inválida - PID: %d Página: %d", pid, pagina);
        return strdup("INVALID");
    }

    int marco = entrada->marco;
    void* origen = espacio_usuario + marco * TAM_PAGINA;

    char* copia = malloc(TAM_PAGINA);
    memcpy(copia, origen, TAM_PAGINA);
    obtener_metricas(pid)->lecturas++;
    return copia;
}

proceso_memoria_t* buscar_proceso(int pid) {
    bool _match_pid(void* elemento) {
        proceso_memoria_t* proceso = (proceso_memoria_t*) elemento;
        return proceso->pid == pid;
    }

    return list_find(procesos_en_memoria, _match_pid);
}

void enviar_param_string(int socket, const char* string) {
    int longitud = strlen(string) + 1; // el mas 1 por el '\0'

    // enviamos la longitud al socket
    if (send(socket, &longitud, sizeof(int), 0) <= 0) {
        perror("Error enviando la longitud del string");
        return;
    }

    // enviamos el contenido del socket
    if (send(socket, string, longitud, 0) <= 0) {
        perror("Error enviando el contenido del string");
        return;
    }
}

void iniciar_memoria() {
    pseudocodigos = dictionary_create();
    procesos_en_memoria = list_create();
    int tam_memoria = config_get_int_value(config, "TAM_MEMORIA");
    espacio_usuario = malloc(tam_memoria);

    log_info(logger, "SWAP inicializado con %d bytes", tam_memoria);
    log_info(logger, "Espacio de memoria inicializado con %d bytes", tam_memoria);
}

char** obtener_instrucciones_para_pid(int pid) {
    char pid_str[10];
    sprintf(pid_str, "%d", pid);

    if (!dictionary_has_key(pseudocodigos, pid_str)) {
        char ruta[64];
        sprintf(ruta, "pseudocodigo/%d.txt", pid);
        char** instrucciones = leer_lineas_archivo(ruta);
        dictionary_put(pseudocodigos, strdup(pid_str), instrucciones);
    }

    return dictionary_get(pseudocodigos, pid_str);
}

int obtener_espacio_libre_mock() {
    return 4096; //a modo de ejemplo
}

void enviar_param_int(int socket, int valor) {
    send(socket, &valor, sizeof(int), 0);
}

void enviar_respuesta(int fd, int codigo_respuesta) {
    send(fd, &codigo_respuesta, sizeof(int), 0);
}

void enviar_lista_instrucciones(int socket_cliente, t_list* instrucciones) {

    int cantidad = list_size(instrucciones);
    send(socket_cliente, &cantidad, sizeof(int), 0);

    for (int i = 0; i < cantidad; i++) {
        char* instr = list_get(instrucciones, i);
        int len = strlen(instr) + 1;
        send(socket_cliente, &len, sizeof(int), 0);        // longitud de la instrucción
        send(socket_cliente, instr, len, 0);               // instrucción
    }
    // list_destroy_and_destroy_elements(instrucciones, free);
    // ESTA LISTA LA ESTOY GUARDANDO EN UN DICTIONARY_PUT()
}

char* recv_param_string(int socket) {
    int longitud;

    if (recv(socket, &longitud, sizeof(int), MSG_WAITALL) <= 0) {
        perror("[recv_param_string] Error recibiendo longitud del string");
        exit(EXIT_FAILURE);
    }

    char* buffer = malloc(longitud + 1);
    if (recv(socket, buffer, longitud, MSG_WAITALL) <= 0) {
        perror("[recv_param_string] Error recibiendo string");
        free(buffer);
        exit(EXIT_FAILURE);
    }

    buffer[longitud] = '\0';
    return buffer;
}

void recv_param_int(int socket, int* destino) {      
    int bytes_recibidos = recv(socket, destino, sizeof(int), 0);
    
    if (bytes_recibidos <= 0) {
        perror("Error al recibir int");
        // Opcional: salir o manejar el error de forma adecuada
        close(socket);
    }
}

int obtener_marco_libre(){
    for(int i=0; i<MAX_MARCOS; i++){
        if(!marcos_usados[i]){
            marcos_usados[i] = true;
            return i;
        }
    }
    
    log_error(logger, "No hay marcos disponibles");
    return -1;
}





void logear_destruccion_proceso(int pid) {
    metricas_proceso_t* metrica = obtener_metricas(pid); // COMPLETAR!!!!! implementar esta función con list_find

    int acces           = metrica->accesos_tablas_paginas;
    int bajadas_swap    = metrica->bajadas_a_swap;
    int subidas_memoria = metrica->subidas_a_memoria;
    int lecturas        = metrica->lecturas;
    int escrituras      = metrica->escrituras;

    log_info(logger, "## PID: %d - Proceso Destruido - Métricas - Acc.T.Pag: %d; Inst.Sol.: %d; SWAP: %d; Mem.Prin.: %d; Lec.Mem.: %d; Esc.Mem.: %d", pid, acces, pid, bajadas_swap , subidas_memoria, lecturas, escrituras);
    

}

int contar_marcos_libres() {
    int libres = 0;
    for(int i=0; i<MAX_MARCOS; i++) {
        if(!marcos_usados[i]) libres ++;
    }
    return libres;
}


entrada_tabla_pagina_t* obtener_entrada(proceso_memoria_t* proceso, int pagina_logica) {
    tabla_paginas_t* tabla_actual = proceso->tabla_primer_nivel;

    int niveles = config_get_int_value(config, "CANTIDAD_NIVELES");
    int entradas_por_tabla = config_get_int_value(config, "ENTRADAS_POR_TABLA");

    int indices[niveles];
    int pagina_aux = pagina_logica;

    // Calcular los índices de cada nivel desde el más bajo al más alto


    for (int i = niveles - 1; i >= 0; i--) {
        indices[i] = pagina_aux % entradas_por_tabla;
        pagina_aux /= entradas_por_tabla;
    }
    for (int nivel = 0; nivel < niveles; nivel++) {
        int idx = indices[nivel];

        if (idx >= list_size(tabla_actual->entradas)) {
            log_error(logger, "[MEMORIA] Entrada fuera de rango en nivel %d (indice %d)", nivel, idx);
            return NULL;
        }

        void* entrada = list_get(tabla_actual->entradas, idx);


        if (nivel == niveles - 1) {
            // Último nivel: entrada real
            entrada_tabla_pagina_t* entrada_final = (entrada_tabla_pagina_t*) entrada;
            if (!entrada_final->presente || entrada_final->marco == -1) {
                log_warning(logger, "[MEMORIA] Entrada no presente o marco inválido en PID %d - Página %d (nivel %d - índice %d)", proceso->pid, pagina_logica, nivel, idx);
                return NULL;
            }

            return entrada_final;
        } else {
            // Tabla intermedia: bajamos un nivel
            tabla_paginas_t* siguiente_tabla = (tabla_paginas_t*) entrada;

            if (!siguiente_tabla || !siguiente_tabla->entradas) {
                log_error(logger, "[MEMORIA] Tabla intermedia NULL en nivel %d (indice %d)", nivel, idx);
                return NULL;
            }

            tabla_actual = siguiente_tabla;
        }
    }


    log_error(logger, "[MEMORIA] No se pudo obtener la entrada para PID %d - Página %d", proceso->pid, pagina_logica);
    return NULL;
}



tabla_paginas_t* crear_tabla_nivel(int nivel_actual, int nivel_maximo, int* paginas_restantes) {
    tabla_paginas_t* tabla = malloc(sizeof(tabla_paginas_t));
    tabla->nivel = nivel_actual;
    tabla->entradas = list_create();

    int entradas_por_tabla = config_get_int_value(config, "ENTRADAS_POR_TABLA");

    for (int i = 0; i < entradas_por_tabla; i++) {
        if (nivel_actual == nivel_maximo - 1) {
            // Último nivel: entrada de página real
            if (*paginas_restantes <= 0) break;
            entrada_tabla_pagina_t* entrada = malloc(sizeof(entrada_tabla_pagina_t));
            entrada->marco = obtener_marco_libre(); // si no hay, -1
            entrada->presente = entrada->marco != -1;
            entrada->modificado = false;
            entrada->usado = false;
            list_add(tabla->entradas, entrada);
            (*paginas_restantes)--;
        } else {
            // Nivel intermedio: tabla secundaria
            tabla_paginas_t* subtabla = crear_tabla_nivel(nivel_actual + 1, nivel_maximo, paginas_restantes);
            if (subtabla) list_add(tabla->entradas, subtabla);
        }
    }

    return tabla;
}

// void crear_tablas_recursivo(tabla_paginas_t* tabla_actual, int nivel_restante, int entradas_por_tabla, int* paginas_restantes) {
//     for (int i = 0; i < entradas_por_tabla; i++) {
//         if (nivel_restante == 1) {
//             // Último nivel: crear entrada de página
//             entrada_tabla_pagina_t* entrada = malloc(sizeof(entrada_tabla_pagina_t));

//             if (*paginas_restantes > 0) {
//                 int marco = obtener_marco_libre();
//                 if (marco == -1) {
//                     log_error(logger, "[MEMORIA] No hay marcos libres para asignar página");
//                     // Aún así agregamos la entrada, pero inválida
//                     entrada->marco = -1;
//                     entrada->presente = false;
//                 } else {
//                     entrada->marco = marco;
//                     entrada->presente = true;
//                     (*paginas_restantes)--;
//                 }
//             } else {
//                 entrada->marco = -1;
//                 entrada->presente = false;
//             }

//             entrada->modificado = false;
//             entrada->usado = false;

//             list_add(tabla_actual->entradas, entrada);
//         } else {
//             // Nivel intermedio: crear subtabla
//             tabla_paginas_t* tabla_nueva = malloc(sizeof(tabla_paginas_t));
//             tabla_nueva->id = i;
//             tabla_nueva->nivel = tabla_actual->nivel + 1;
//             tabla_nueva->entradas = list_create();

//             list_add(tabla_actual->entradas, tabla_nueva);
//             crear_tablas_recursivo(tabla_nueva, nivel_restante - 1, entradas_por_tabla, paginas_restantes);
//         }
//     }
// }

void crear_tablas_recursivo(tabla_paginas_t* tabla_actual, int nivel_restante, int entradas_por_tabla, int* paginas_restantes) {
    for (int i = 0; i < entradas_por_tabla && *paginas_restantes > 0; i++) {
        if (nivel_restante == 1) {
            // Último nivel: crear entrada de página (con o sin marco)
            entrada_tabla_pagina_t* entrada = malloc(sizeof(entrada_tabla_pagina_t));
            int marco = obtener_marco_libre();

            if (marco != -1) {
                entrada->marco = marco;
                entrada->presente = true;
            } else {
                entrada->marco = -1;
                entrada->presente = false;
                log_warning(logger, "[MEMORIA] Página sin marco asignado en creación inicial. Se marcará como no presente.");
            }

            entrada->modificado = false;
            entrada->usado = false;

            list_add(tabla_actual->entradas, entrada);
            (*paginas_restantes)--;
        } else {
            // Nivel intermedio: crear subtabla
            tabla_paginas_t* tabla_nueva = malloc(sizeof(tabla_paginas_t));
            tabla_nueva->id = i;
            tabla_nueva->nivel = tabla_actual->nivel + 1;  // 👈 este +1 ahora funcionará correctamente
            tabla_nueva->entradas = list_create();

            list_add(tabla_actual->entradas, tabla_nueva);
            crear_tablas_recursivo(tabla_nueva, nivel_restante - 1, entradas_por_tabla, paginas_restantes);
        }
    }
}





