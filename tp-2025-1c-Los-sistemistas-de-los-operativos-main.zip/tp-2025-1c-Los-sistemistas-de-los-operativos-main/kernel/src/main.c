#include <utils/hello.h>
#include <kernel.h>
#include <socket_kernel.h>
#include <pcb.h>
#include <planif_largo.h>
#include <planif_corto.h>
#include <planif_medio.h>

char* algoritmo_planificacion; 
bool iniciar_planificador = false;  
int ESTIMACION_INICIAL;
double ALFA;

t_log* logger = NULL;
t_config* config = NULL;

t_queue* cola_new = NULL;
t_queue* cola_ready = NULL;
t_queue* cola_exec = NULL;
t_queue* cola_blocked = NULL;
t_queue* cola_blocked_suspended = NULL;
t_queue* cola_suspended_ready = NULL;
t_queue* cola_exit = NULL;

extern pthread_mutex_t mutex_new;
extern pthread_mutex_t mutex_ready;
extern pthread_mutex_t mutex_blocked;
extern pthread_mutex_t mutex_exec;
extern pthread_mutex_t mutex_blocked_suspended;
extern pthread_mutex_t mutex_suspended_ready;
extern pthread_mutex_t mutex_exit;

sem_t sem_largo_plazo;
sem_t proceso_en_ready;
sem_t semaforo_proceso;

sem_t sem_conexion_kernel;

extern t_list* cpus_conectadas;
t_list* lista_ready = NULL;

//IMPORTANTE    
//
// 1- Tenemos muchas funciones que no utilizamos (sacadas del TP0)
// 2- Buscar la palabra "COMPLETAR!" para ir corrigiendo cosas que fui viendo

void esperar_enter() {
    log_info(logger,"Presiona Enter para iniciar la planificación...\n");
    getchar();
    iniciar_planificador = true;
}

//___________________MAIN______________________//
int main(int argc, char* argv[]){
    logger = iniciar_logger();
    config = iniciar_config();

    if (argc < 3) {
        fprintf(stderr, "Uso: %s <archivo_de_prueba> <tamanio_proceso>\n", argv[0]);
        return EXIT_FAILURE;
    }

    //argv[0] = ./bin/kernel    aca lo vengo a buscar
    //argv[1] = nombre que le pongo
    //argv[2] = tamanio del pseudocodigo que le pongo

    //pthread_t hilo_procesos, hilo_interrupciones;

    log_info(logger, "Iniciando KERNEL "); 
    
    //------INICIALIZACIONES Y ASIGNACIONES------

    //CONFIGS

    char* puerto_escucha_io = config_get_string_value(config, "PUERTO_ESCUCHA_IO");
    int servidor_io = iniciar_kernel_servidor(puerto_escucha_io);
    int* arg_io = malloc(sizeof(int));
    *arg_io = servidor_io;

    dispositivos_io = list_create();
    pthread_mutex_init(&mutex_dispositivos_io, NULL);

    pthread_t hilo_aceptar_io;
    pthread_create(&hilo_aceptar_io, NULL, aceptar_ios, arg_io);
    pthread_detach(hilo_aceptar_io);

    //char* algoritmo_planificacion = config_get_string_value(config, "ALGORITMO_INGRESO_A_READY"); 
    
    char* puerto_procesos = config_get_string_value(config, "PUERTO_ESCUCHA_DISPATCH");     
    char* puerto_interrupciones = config_get_string_value(config, "PUERTO_ESCUCHA_INTERRUPT");      
    
    int servidor_procesos = iniciar_kernel_servidor(puerto_procesos);
    int servidor_interrupciones = iniciar_kernel_servidor(puerto_interrupciones);
    
    log_info(logger,"Esperando CPU");

    //COLAS
    cola_new = queue_create();
    cola_ready = queue_create();
    cola_exec = queue_create();
    cola_blocked = queue_create();
    cola_blocked_suspended = queue_create();
    cola_suspended_ready = queue_create();
    cola_exit = queue_create();

    //MUTEX
    pthread_mutex_init(&mutex_new, NULL);
    pthread_mutex_init(&mutex_ready, NULL);
    pthread_mutex_init(&mutex_exec, NULL);
    pthread_mutex_init(&mutex_blocked, NULL);
    pthread_mutex_init(&mutex_blocked_suspended, NULL);
    pthread_mutex_init(&mutex_suspended_ready, NULL);
    pthread_mutex_init(&mutex_exit, NULL);

    pthread_mutex_init(&mutex_cpus, NULL);
    sem_init(&sem_largo_plazo, 0, 0);  
    sem_init(&proceso_en_ready, 0, 0);
    sem_init(&sem_conexion_kernel, 0, 1);   //para que haya un solo kernel a la vez


    //INICIALIZO VARIABLES GLOBALES
    cpus_conectadas = list_create();

    argumentos_aceptar_cpu_t* args_aceptar_cpu = malloc(sizeof(argumentos_aceptar_cpu_t));
    args_aceptar_cpu->servidor_procesos = servidor_procesos;
    args_aceptar_cpu->servidor_interrupciones = servidor_interrupciones;
    
    //args_aceptar_cpu->servidor_io = servidor_io   COMPLETAR, CUANDO SE HAGA HILO SE TIENEN QUE PODER MANEJAR MUCHAS IOS
    //HACER UN HILO DE ACEPTAR IOS Y PASARLE POR PARAMETRO EL SOCKET AL HILO DE CPU

    pthread_t hilo_aceptar;
    pthread_create(&hilo_aceptar, NULL, aceptar_cpus, args_aceptar_cpu);
    pthread_detach(hilo_aceptar);


    char* archivo_pseudocodigo = argv[1];
    int tamanio_proceso = atoi(argv[2]);

    //argumentos_planificador_t* args_procesos = malloc(sizeof(argumentos_planificador_t));

    //args_procesos->socket_io = socket_io;
    // args_procesos->cola_new = cola_new;
    // args_procesos->cola_suspended_ready = cola_suspended_ready;
    //args_procesos->nombre_archivo = argv[1];

    
    //pthread_create(&hilo_procesos, NULL, manejar_cpu_procesos, args_procesos);      //maneja las devoluciones de la CPU
    //pthread_create(&hilo_interrupciones, NULL, manejar_cpu_interrupciones, socket_interrupciones);

    //CREAMOS PROCESO INICIAL

    ESTIMACION_INICIAL = config_get_int_value(config, "ESTIMACION_INICIAL");
    ALFA = config_get_double_value(config, "ALFA");
    

    log_info(logger, "La estimacion inicial fue ajustada a: %d", ESTIMACION_INICIAL);
    log_info(logger, "El alfa seleccionado es de: %f", ALFA);
    
    
    pcb_t* pcb_proceso_nuevo = crear_proceso_pseudocodigo(archivo_pseudocodigo, tamanio_proceso);
    pthread_mutex_lock(&mutex_new);
    queue_push(cola_new, pcb_proceso_nuevo);
    pthread_mutex_unlock(&mutex_new);

    log_info(logger, "Habilito planificador largo");
    sem_post(&sem_largo_plazo);

    //--------------LARGO PLAZO----------------
      

    log_info(logger, "Iniciando planificador LARGO PLAZO");
    esperar_enter();
    inicializar_planificador_largo_plazo();


    //--------------MEDIANO PLAZO----------------
    // log_info(logger, "Iniciando planificador MEDIO PLAZO");

    // argumentos_planificador_medio_t* args_planificador_medio = malloc(sizeof(argumentos_planificador__t));
    // args_planificador_medio->socket_memoria = socket_memoria;
    // args_planificador_medio->tiempo_suspension = config_get_int_value(config, "TIEMPO_SUSPENSION");

    // inicializar_planificador_mediano_plazo();

    //----CORTO PLAZO--------
    argumentos_planificador_t* args_planificador = malloc(sizeof(argumentos_planificador_t));
    //args_planificador->socket_procesos = socket_procesos;
    //args_planificador->socket_interrupciones = socket_interrupciones;

 
    log_info(logger, "Iniciando planificador CORTO PLAZO");
    inicializar_planificador_corto_plazo(args_planificador);

    //--------------------------------------

    //Cuando la CPU devuelve EXIT o una syscall EXIT:
    //ESTO NO VA EN EL MAIN. Va en el hilo de manejar procesos CPU
    //log_info(logger,"Finalizando proceso %d", proceso->pid);
    //_proceso(proceso, cola_new, cola_suspended_ready);


    while(1){
        int i = 0;
    }

    //LIBERAMOS CONEXIONES

    liberar_conexion(servidor_procesos);
    liberar_conexion(servidor_interrupciones);

    // pthread_join(hilo_planificador_largo, NULL);
    // pthread_join(hilo_planificador, NULL);
    //pthread_join(hilo_procesos, NULL);
    //pthread_join(hilo_interrupciones, NULL);
    
    //liberar_conexion(servidor_io);
    sem_destroy(&sem_largo_plazo);
    sem_destroy(&semaforo_proceso);
    

    log_destroy(logger);
    config_destroy(config);

    log_info(logger, "++++++++++++++++++++++++++++Fin Kernel++++++++++++++++++++++++++++");

    return 0;
}
