#include<utils/hello.h>
#include <commons/string.h>

#ifndef PLANIFICADOR_LARGO_PLAZO_H
#define PLANIFICADOR_LARGO_PLAZO_H

//#define TAM_PAGINA 64  //dejo este valor como el tamanio fijo de las paginas. En la CPU defini el mismo tamanio

//VOY A ASIGNARLE UN CODIGO A CADA OPCION QUE NECESITE LA CONEXION PARA HACERLO MAS FACIL
//Y NO OLVIDARMELOS

// Códigos entre Kernel y Memoria
#define INIT_PROC   1     // Solicitud de inicialización de proceso
#define EXIT_PROC   2     // Finalización de proceso
#define DUMP_MEMORY 3     // Dump solicitado por syscall

// Respuestas de Memoria al Kernel
#define MEM_OK      100   // Memoria acepta el proceso
#define MEM_ERROR   101   // Memoria no puede alojar el proceso
#define MEM_SWAP_OK 102   // Confirmación de swap
#define MEM_SWAP_ERR 103  // Fallo al intentar swap



#define DESUSPENDER_PROC 104 // Solicitud de restaurar proceso desde SWAP
#define SUSPENDER_PROC 105

// para la actualizacion de paginas:
//typedef struct {
//    int pid;
//    char** paginas; // array de strings, cada uno es una "página"
//    int cantidad_paginas;
//} proceso_memoria_t;

extern t_list* procesos_memoria;
extern int entradas_por_pagina;

typedef struct {
    int marco;
    bool presente;
    bool modificado;
    bool usado;
} entrada_tabla_pagina_t;

typedef struct {
    int nivel;
    int id;
    t_list* entradas; 
    int pid;    // OJO se puede sacar
} tabla_paginas_t;

typedef struct {
    int pid;
    tabla_paginas_t* tabla_primer_nivel;
    int cantidad_paginas;
} proceso_memoria_t;

extern void inicializar_swap();

void* atender_conexion_kernel(void* arg);
void* atender_conexion_cpu(void* arg);
void enviar_param_string(int socket,const char* string);

void enviar_lista_instrucciones(int socket, t_list* instrucciones);

void actualizar_contenido_pagina(int pid, int pagina, const char* contenido);
char* leer_pagina_de_memoria(int pid, int pagina);

proceso_memoria_t* buscar_proceso(int pid);
bool _match_pid(void* elemento);

t_list* leer_instrucciones_de_archivo(char* nombre_archivo);

char* recv_param_string(int socket);

void recv_param_int(int socket, int* destino);

int obtener_marco_libre();
int contar_marcos_libres();
entrada_tabla_pagina_t* obtener_entrada(proceso_memoria_t* proceso, int pagina_logica);

void logear_destruccion_proceso(int pid);

tabla_paginas_t* crear_tabla_nivel(int nivel_actual, int nivel_maximo, int* paginas_restantes);

void crear_tablas_recursivo(tabla_paginas_t* tabla_actual, int nivel_restante, int entradas_por_tabla, int* paginas_restantes);

#endif // PLANIFICADOR_LARGO_PLAZO_H
