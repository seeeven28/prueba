#ifndef PLANIF_MEDIO_H_
#define PLANIF_MEDIO_H_

#include <utils/hello.h>
#include "pcb.h"

void inicializar_planificador_mediano_plazo(int socket_memoria);
void reintentar_ingreso_a_ready();
void finalizar_io_mediano(int pid);
void enviar_codigo_operacion(int cod_op, int socket_destino);

#endif


