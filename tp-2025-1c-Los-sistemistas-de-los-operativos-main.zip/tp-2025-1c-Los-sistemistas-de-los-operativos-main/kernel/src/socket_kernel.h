#ifndef SOCKET_KERNEL_H_
#define SOCKET_KERNEL_H_

#include <utils/hello.h>

#define PUERTO_PROCESOS "4444"
#define PUERTO_INTERRUPCIONES "5555"
#define PUERTO_MEMORIA "6666"
#define IP "127.0.0.1"
#define OPCODE_HANDSHAKE_IO 1
#define OPCODE_IO_REQUEST   2
#define OPCODE_IO_FIN       3

typedef enum
{
    MENSAJE = 0,
    PAQUETE = 1,
    tres=3,
    cuatro=4,
    cinco=5
}op_code;

//____________HEARDERS PARA KERNEL COMO SERVIDOR______________________
typedef struct
{
    int size;
    void* stream;
} t_buffer;

typedef struct
{
    op_code codigo_operacion;
    t_buffer* buffer;
} t_paquete;

//_________________FUNCIONES TP0 - SERVIDOR_____________________
int iniciar_kernel_servidor(const char*);
int esperar_cliente(int);
char* recibir_buffer(int*, int);
t_list* recibir_paquete(int);
char* recibir_mensaje(int socket_cliente);
int recibir_operacion(int);

//___________FUNCIONES DEL TP0 - CLIENTE________________________
void enviar_mensaje(char* , int);
void liberar_conexion(int);

int iniciar_kernel_cliente(const char* ip, const char* puerto);

t_paquete* crear_paquete(void);
void agregar_a_paquete(t_paquete* paquete, void* valor, int tamanio);
void enviar_paquete(t_paquete* paquete, int socket_cliente);
void eliminar_paquete(t_paquete* paquete);
void* serializar_paquete(t_paquete*, int);
void enviar_codigo_operacion(int, int);

//___________________________________________________

void* aceptar_ios(void* arg);

#endif // SOCKET_KERNEL_H
