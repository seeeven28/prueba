#ifndef SWAP_H
#define SWAP_H
#include<utils/hello.h>
#include <stdbool.h>
#include "mem_largo_plazo.h"
#include "mem.h"

extern t_log* logger;
extern void* espacio_usuario;
//extern bool marcos_usados[];
extern bool* marcos_usados;
extern int TAM_PAGINA;

bool escribir_en_swap(int pid, void* contenido, int tamanio);
void* leer_de_swap(int pid, int tamanio);
void eliminar_proceso_swap(int pid);
void inicializar_swap(char* path, int retardo_swap);
void cerrar_swap();

bool suspender_a_swap(int pid);
bool desuspender_de_swap(int pid);

#endif
