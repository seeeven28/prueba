#ifndef CLIENT_H_
#define CLIENT_H_

#include<utils/hello.h>
#include "planif_corto.h"
#include "planif_largo.h"
#include "pcb.h"
#include <semaphore.h>

#define ESTADOS 7

//Codigos de operacion de la CPU (uso INSTR_IO para mandarle al IO ese codigo de operacion)
#define INSTR_NOOP        501
#define INSTR_WRITE       502
#define INSTR_READ        503
#define INSTR_GOTO        504
#define INSTR_IO          505   
#define INSTR_INIT_PROC   506
#define INSTR_DUMP_MEMORY 507
#define INSTR_EXIT        508
#define ESCRIBIR_PAGINA     509
#define DEVOLUCION_PROCESO  510

typedef struct {
    int servidor_procesos;
    int servidor_interrupciones;
} argumentos_aceptar_cpu_t;

typedef struct {
    char* nombre;
    int socket_fd;
    t_queue* cola_bloqueados;
    bool ocupado;
    pthread_mutex_t mutex;
} dispositivo_io_t;


typedef struct {
    int socket_io;
    int socket_interrupciones;
} argumentos_io_t;


extern t_list* dispositivos_io;
extern pthread_mutex_t mutex_dispositivos_io;


extern t_config* config;
extern t_log* logger;

t_log* iniciar_logger(void);
t_config* iniciar_config(void);

void* aceptar_cpus(void* args_void);

void iterator(void* value);
void* crear_hilo_interrupciones(void* arg);
void* crear_hilo_procesos(void* arg);

void* manejar_cpu_procesos(void*);
void* manejar_cpu_interrupciones(void*);
void* manejar_io(void* arg);

pcb_t* buscar_pcb_por_pid(int pid);
pcb_t* crear_proceso_pseudocodigo(char* archivo_pseudocodigo, int tamanio_proceso);

void parsear_archivo_de_pruebas(char* ruta_archivo);

void pasar_a_bloqueado(int pid, int socket_io);

char* recv_param_string(int socket);

void recv_param_int(int socket, int* destino);

void enviar_request_io(dispositivo_io_t* dispositivo, int pid, int tiempo);
void syscall_io(pcb_t* pcb, char* nombre_io, int tiempo);

pcb_t* remover_pcb_de_cola(t_queue* cola, pthread_mutex_t* mutex, int pid);
pcb_t* encontrar_y_remover_pcb(int pid);
void queue_push_comienzo(t_queue* cola, pcb_t* pcb, pthread_mutex_t* mutex);

#endif /* CLIENT_H_ */
