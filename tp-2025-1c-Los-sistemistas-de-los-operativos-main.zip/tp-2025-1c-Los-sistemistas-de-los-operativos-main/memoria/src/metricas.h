
#include<utils/hello.h>
#include <stdbool.h>
#include <commons/string.h>






// void agregar_metrica(int pid);
// metricas_proceso_t* obtener_metricas(int pid);  
// void incrementar_acceso_tabla(int pid);
// void incrementar_instrucciones(int pid);
// void incrementar_bajada_swap(int pid);
// void incrementar_subida_memoria(int pid);
// void incrementar_lectura(int pid);              
// void incrementar_escritura(int pid);            
// void imprimir_metricas_y_liberar(int pid);      

// #endif

#ifndef METRICAS_H
#define METRICAS_H

#include <commons/collections/list.h>

typedef struct {
    int pid;
    int accesos_tablas_paginas;
    int instrucciones_solicitadas;
    int bajadas_a_swap;
    int subidas_a_memoria;
    int lecturas;
    int escrituras;
} metricas_proceso_t;

extern t_list* metricas;

void agregar_metrica(int pid);
metricas_proceso_t* obtener_metricas(int pid);
void incrementar_lectura(int pid);
void incrementar_escritura(int pid);
void imprimir_metricas_y_liberar();

#endif
