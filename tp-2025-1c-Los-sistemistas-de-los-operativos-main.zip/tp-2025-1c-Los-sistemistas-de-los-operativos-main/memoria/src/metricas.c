#include "metricas.h"
#include <commons/collections/dictionary.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <commons/log.h>

extern t_log* logger;

static t_dictionary* metricas_por_pid = NULL;

t_list* metricas = NULL;

static char* pid_to_key(int pid) {
    return string_itoa(pid);
}

void agregar_metrica(int pid) {
    if (!metricas)
        metricas = list_create();

    metricas_proceso_t* nueva = malloc(sizeof(metricas_proceso_t));
    nueva->pid = pid;
    nueva->accesos_tablas_paginas = 0;
    nueva->instrucciones_solicitadas = 0;
    nueva->bajadas_a_swap = 0;
    nueva->subidas_a_memoria = 0;
    nueva->lecturas = 0;
    nueva->escrituras = 0;

    list_add(metricas, nueva);
}


metricas_proceso_t* obtener_metricas(int pid) {
    if (!metricas_por_pid) {
        metricas_por_pid = dictionary_create();
    }

    char* key = pid_to_key(pid);
    if (!dictionary_has_key(metricas_por_pid, key)) {
        metricas_proceso_t* m = calloc(1, sizeof(metricas_proceso_t));
        dictionary_put(metricas_por_pid, key, m);
    }

    metricas_proceso_t* result = dictionary_get(metricas_por_pid, key);
    free(key);
    return result;
}

void incrementar_acceso_tabla(int pid) {
    obtener_metricas(pid)->accesos_tablas_paginas++;
}

void incrementar_instrucciones(int pid) {
    obtener_metricas(pid)->instrucciones_solicitadas++;
}

void incrementar_bajada_swap(int pid) {
    obtener_metricas(pid)->bajadas_a_swap++;
}

void incrementar_subida_memoria(int pid) {
    obtener_metricas(pid)->subidas_a_memoria++;
}

void incrementar_lectura(int pid) {
    obtener_metricas(pid)->lecturas++;
}

void incrementar_escritura(int pid) {
    obtener_metricas(pid)->escrituras++;
}

void imprimir_metricas_y_liberar(int pid) {
    char* key = pid_to_key(pid);
    metricas_proceso_t* m = dictionary_remove(metricas_por_pid, key);

    if (m != NULL) {
        log_info(logger, "## PID: %d - Proceso Destruido - Metricas - Acc.T.Pag: %d; Inst.Sol.: %d; SWAP: %d; Mem.Prin.: %d; Lec.Mem.: %d; Esc.Mem.: %d",
        pid, m->accesos_tablas_paginas, m->instrucciones_solicitadas,
        m->bajadas_a_swap, m->subidas_a_memoria,
        m->lecturas, m->escrituras);

        free(m);
    }

    free(key);
}
