#include <socket_mem.h>
#include <mem.h>
#include <utils/hello.h>


extern t_log* logger;
extern t_config* config;


int iniciar_memoria_servidor(const char* puerto_memoria) {
    int socket_servidor;
    int err;
    struct addrinfo hints, *serverinfo;

    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags = AI_PASSIVE;

    err = getaddrinfo(NULL, puerto_memoria, &hints, &serverinfo);
    if (err != 0) {
        perror("MEMORIA: ERROR GETADDRINFO\n");
        exit(EXIT_FAILURE);
    }

    socket_servidor = socket(serverinfo->ai_family,
                            serverinfo->ai_socktype,
                            serverinfo->ai_protocol);
                                                   
    if (socket_servidor == -1) {
        perror("MEMORIA: ERROR al crear socket\n");
        freeaddrinfo(serverinfo);
        exit(EXIT_FAILURE);
    }

    err = setsockopt(socket_servidor, SOL_SOCKET, SO_REUSEPORT, &(int){1}, sizeof(int));
    if (err == -1) {
        perror("MEMORIA: ERROR setsockopt\n");
        close(socket_servidor);
        freeaddrinfo(serverinfo);
        exit(EXIT_FAILURE);
    }

    err = bind(socket_servidor, serverinfo->ai_addr, serverinfo->ai_addrlen);
    if (err == -1) {
        perror("MEMORIA: ERROR bind\n");
        close(socket_servidor);
        freeaddrinfo(serverinfo);
        exit(EXIT_FAILURE);
    }

    err = listen(socket_servidor, SOMAXCONN);
    if (err == -1) {
        perror("MEMORIA: ERROR listen\n");
        close(socket_servidor);
        freeaddrinfo(serverinfo);
        exit(EXIT_FAILURE);
    }

    freeaddrinfo(serverinfo);
    return socket_servidor;
}

int esperar_cliente(int socket_servidor){
    int socket_cliente = accept(socket_servidor, NULL, NULL);
    return socket_cliente;

}

int recibir_operacion(int socket_cliente)
{
	int cod_op;
    int bytes = recv(socket_cliente, &cod_op, sizeof(int), MSG_WAITALL);
	if (bytes == 0){
		//close(socket_cliente);
		return -1;
	}
	if (bytes == -1) {
		perror("MEMORIA: Error en recv");
		//close(socket_cliente);
		return -1;
	}
    
	return cod_op;
}

void* recibir_buffer(int* size, int socket_cliente)
{
	void * buffer;

	recv(socket_cliente, size, sizeof(int), MSG_WAITALL);
	buffer = malloc(*size);
	recv(socket_cliente, buffer, *size, MSG_WAITALL);

	return buffer;
}

void recibir_mensaje(int socket_cliente)
{
	int size;
	char* buffer = recibir_buffer(&size, socket_cliente);
	printf("MEMORIA: Me llego el mensaje %s\n", buffer);
	free(buffer);
}

t_list* recibir_paquete(int socket_cliente){
	int size;
	int desplazamiento = 0;
	void * buffer;
	t_list* valores = list_create();
	int tamanio;

	buffer = recibir_buffer(&size, socket_cliente);
	while(desplazamiento < size)
	{
		memcpy(&tamanio, buffer + desplazamiento, sizeof(int));
		desplazamiento+=sizeof(int);
		char* valor = malloc(tamanio);
		memcpy(valor, buffer+desplazamiento, tamanio);
		desplazamiento+=tamanio;
		list_add(valores, valor);
	}
	free(buffer);
	return valores;
}

void liberar_conexion(int socket){
    close(socket);
}
///////



void enviar_mensaje(char* mensaje, int socket_cliente)
{
	t_paquete* paquete = malloc(sizeof(t_paquete));

	paquete->codigo_operacion = MENSAJE;
	paquete->buffer = malloc(sizeof(t_buffer));
	paquete->buffer->size = strlen(mensaje) + 1;
	paquete->buffer->stream = malloc(paquete->buffer->size);
	memcpy(paquete->buffer->stream, mensaje, paquete->buffer->size);

	int bytes = paquete->buffer->size + 2*sizeof(int);

	void* a_enviar = serializar_paquete(paquete, bytes);

	send(socket_cliente, a_enviar, bytes, 0);

	free(a_enviar);
	eliminar_paquete(paquete);
}


void* serializar_paquete(t_paquete* paquete, int bytes) {

	void * magic = malloc(bytes);
	int desplazamiento = 0;

	memcpy(magic + desplazamiento, &(paquete->codigo_operacion), sizeof(int));
	desplazamiento+= sizeof(int);
	memcpy(magic + desplazamiento, &(paquete->buffer->size), sizeof(int));
	desplazamiento+= sizeof(int);
	memcpy(magic + desplazamiento, paquete->buffer->stream, paquete->buffer->size);
	desplazamiento+= paquete->buffer->size;

	return magic;
}

void enviar_codigo_operacion(int cod_op, int socket_destino) {
    if (send(socket_destino, &cod_op, sizeof(int), 0) <= 0) {
        perror("Error al enviar código de operación");
    }
}

void eliminar_paquete(t_paquete* paquete)
{
	free(paquete->buffer->stream);
	free(paquete->buffer);
	free(paquete);
}


void responder_mensajes(char* msg, int socket) {
    char* mensaje = msg;
    uint32_t size = strlen(mensaje) + 1;

    send(socket, &size, sizeof(uint32_t), 0);       // Primero envía el tamaño
    send(socket, mensaje, size, 0);                 // Luego el mensaje en sí
}



char** leer_lineas_archivo(char* path) {
    FILE* archivo = fopen(path, "r");
    if (!archivo) return NULL;

    char** lineas = malloc(sizeof(char*) * 100); // hasta 100 instrucciones
    char buffer[256];
    int i = 0;

    while (fgets(buffer, sizeof(buffer), archivo) != NULL) {
        buffer[strcspn(buffer, "\n")] = 0; // quitar '\n'
        lineas[i] = strdup(buffer);
        i++;
    }

    lineas[i] = NULL; // terminar con NULL
    fclose(archivo);
    return lineas;
}