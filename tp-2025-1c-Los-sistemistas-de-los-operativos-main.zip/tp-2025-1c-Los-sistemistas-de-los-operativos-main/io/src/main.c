#include <io.h>
#include <socket_io.h>

t_config* config = NULL;
t_log* logger = NULL;

int main(int argc, char* argv[]) {
    if (argc < 2) {
        fprintf(stderr, "Falta el nombre de la interfaz de IO.\n");
        return EXIT_FAILURE;
    }

    char* nombre_io = argv[1];

    // Para leer el archivo de config
    t_config* config = iniciar_config();
    char* ip_kernel = config_get_string_value(config, "IP_KERNEL");
    char* puerto_kernel = config_get_string_value(config, "PUERTO_KERNEL");          //Lo conecto al puerto 7777
   
    logger = iniciar_logger(config);

    // Conectando al kernel
    log_info(logger,"Conectando con el KERNEL");
    int socket_kernel = iniciar_cliente(ip_kernel, puerto_kernel);

    log_info(logger, "Enviando handshake a kernel");
    enviar_handshake_io(socket_kernel, nombre_io, logger);
    
    

    while (1) {
        t_io_request* request = recibir_io_request(socket_kernel);
        log_info(logger, "HANDSHAKE EXITOSO!");

        log_info(logger, "LLego PID y tiempo de la request PID %d TIEMPO: %d", request->pid, request->tiempo);
        log_info(logger, "## PID: %d - Inicio de IO - Tiempo: %d", request->pid, request->tiempo);
        usleep(request->tiempo * 1000);
        log_info(logger, "## PID: %d - Fin de IO", request->pid);

        
        log_info(logger, "Se va a intentar iniciar IO");
        enviar_finalizacion_io(socket_kernel, request->pid);
        log_info(logger, "Finalizo IO con exito");
        free(request);
    }

    config_destroy(config);
    log_destroy(logger);
    close(socket_kernel);

    return 0;
}

t_log* iniciar_logger(t_config* config){
    char* log_level_str = config_get_string_value(config, "LOG_LEVEL");
    t_log_level log_level = log_level_from_string(log_level_str);

    t_log* nuevo_logger = log_create("io.log", "IO Logger", 1, log_level);
    if(nuevo_logger == NULL){
        perror("IO: No se pudo crear el log");
        exit(EXIT_FAILURE);
    }
    return nuevo_logger;
}

t_config* iniciar_config(void){

    t_config* nuevo_config = config_create("/home/utnso/tp-2025-1c-Los-sistemistas-de-los-operativos/io/src/io.config"); //leo IP y PUERTO de la CPU

    if(nuevo_config==NULL){
        perror("KENEL: Error al obtener el config \n");
        exit(EXIT_FAILURE);
    }
    
    return nuevo_config;    
}

void enviar_handshake_io(int socket_fd, const char* nombre, t_log* logger) {
    uint8_t codigo = OPCODE_HANDSHAKE_IO;
    uint32_t length = strlen(nombre) + 1;

    send(socket_fd, &codigo, sizeof(uint8_t), 0);
    send(socket_fd, &length, sizeof(uint32_t), 0);
    send(socket_fd, nombre, length, 0);

    log_info(logger, "Handshake enviado al Kernel con nombre: %s", nombre);
}
