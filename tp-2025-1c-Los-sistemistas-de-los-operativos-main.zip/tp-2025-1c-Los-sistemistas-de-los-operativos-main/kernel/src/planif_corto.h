#ifndef PLANIFICADOR_CP_H_
#define PLANIFICADOR_CP_H_

#include <pthread.h>
#include <commons/collections/queue.h>          
#include "pcb.h"        
#include <semaphore.h>

#define MOTIVO_IO 8
#define MOTIVO_EXIT 9
#define MOTIVO_REPLANIFICAR 10

typedef struct {
    int socket_procesos;
    int socket_interrupciones;
    int socket_io;
    char* algoritmo_ingreso_ready;
} argumentos_planificador_t;




typedef struct {
    int pid;
    int pc;
    float estimacion;
}t_paquete_proceso;

//devolucion de la cpu (final ciclo de instruccion)
typedef struct {    //esto es lo que le devuelvo al kernel
    int pid;
    int pc;
    int motivo;
} t_devolucion_proceso;

//extern t_list* lista_ready;
extern pthread_mutex_t mutex_ready;

extern pthread_mutex_t mutex_new;
extern pthread_mutex_t mutex_blocked;
extern pthread_mutex_t mutex_exec;
extern pthread_mutex_t mutex_blocked_suspended;
extern pthread_mutex_t mutex_suspended_ready;
extern pthread_mutex_t mutex_exit;


extern pcb_t* proceso_en_cpu;
extern pthread_mutex_t mutex_cpus;

//Manejo de interrupciones
#define DESALOJO 105

void inicializar_planificador_corto_plazo(argumentos_planificador_t* args_planificador);
void* planificador(void* arg);
void pasar_a_ready_SRT(pcb_t* pcb, int socket_interrupciones);
void enviar_proceso_a_cpu(pcb_t* pcb, int socket_procesos);
bool comparar_estimacion(void* proceso1, void* proceso2);
bool comparar_por_rafaga(void* proceso1, void* proceso2);
int comparador_para_sort(void* a, void* b);
void* planificador_corto_plazo(void* _);
void enviar_interrupcion_a_cpu(int* socket_interrupciones);
cpu_conectada_t* elegir_cpu_libre();

void ordenar_segun_rafagas(t_queue cola_ready);
void manejar_devolucion(t_devolucion_proceso devolucion);   //COMPLETAR NO DEFINIDA. la idea se parece a lo que hago en el hilo de CPU en el main de kernel
pcb_t* buscar_pcb_por_pid(int pid);

void cambiar_estado(pcb_t* pcb, estado_proceso_t estado_nuevo);

void calcular_nueva_estimacion(int pid);
int cual_seria_nueva_estimacion(int pid);

void mostrar_cola(t_queue* cola, char* nombre_cola, pthread_mutex_t* mutex);

#endif
