#include "planif_medio.h"
#include "kernel.h"

extern t_log* logger;
extern t_config* config;

extern t_queue* cola_blocked;
extern t_queue* cola_blocked_suspended;
extern t_queue* cola_suspended_ready;
extern t_queue* cola_ready;
extern t_queue* cola_new;

extern pthread_mutex_t mutex_blocked;
extern pthread_mutex_t mutex_blocked_suspended;
extern pthread_mutex_t mutex_suspended_ready;
extern pthread_mutex_t mutex_ready;
extern pthread_mutex_t mutex_new;

int socket_memoria_global;

void* monitor_suspension_blocked(void* _){
    int tiempo_suspension = config_get_int_value(config, "TIEMPO_SUSPENSION");

    while (1){
        sleep(1);

        pthread_mutex_lock(&mutex_blocked);
        int size = queue_size(cola_blocked);
        for(int i=0; i<size; i++){
            pcb_t* pcb = queue_pop(cola_blocked);
            int tiempo = temporal_gettime(pcb->temporizadores[BLOCKED]);

            if(tiempo >= tiempo_suspension){
                cambiar_estado(pcb, BLOCKED_SUSPENDED);
                log_info(logger, "## (%d) Pasa del estado BLOCKED al estado SUSP. BLOCKED", pcb->pid);

                enviar_codigo_operacion(DESUSPENDER_PROC, socket_memoria_global);
                send(socket_memoria_global, &pcb->pid, sizeof(int), 0);
                log_info(logger, "Se informa a memoria la suspension de PID %d", pcb->pid);

                pthread_mutex_lock(&mutex_blocked_suspended);
                queue_push(cola_blocked_suspended, pcb);
                pthread_mutex_unlock(&mutex_blocked_suspended);
            } else {
                queue_push(cola_blocked, pcb);
            }
        }

        pthread_mutex_unlock(&mutex_blocked);
    }

    return NULL;
}



void reintentar_ingreso_a_ready() {
    // suspended ready
    pthread_mutex_lock(&mutex_suspended_ready);
    int size = queue_size(cola_suspended_ready);
    for(int i=0; i<size; i++) {
        pcb_t* pcb = queue_pop(cola_suspended_ready);

        enviar_codigo_operacion(DESUSPENDER_PROC, socket_memoria_global);
        send(socket_memoria_global, &pcb->pid, sizeof(int), 0);

        int respuesta;
        recv(socket_memoria_global, &respuesta, sizeof(int), MSG_WAITALL);

        if(respuesta == MEM_OK) {
            cambiar_estado(pcb, READY);
            log_info(logger, "## (%d) Pasa del estado SUSP. READY al estado READY", pcb->pid);

            pthread_mutex_lock(&mutex_ready);
            queue_push(cola_ready, pcb);
            pthread_mutex_unlock(&mutex_ready);
        } else {
            queue_push(cola_suspended_ready, pcb);
        }
    }

    pthread_mutex_unlock(&mutex_suspended_ready);

    // new

    if(queue_is_empty(cola_suspended_ready)) {
        pthread_mutex_lock(&mutex_new);
        int size_new = queue_size(cola_new);
        for(int i=0; i<size_new; i++){
            pcb_t* pcb = queue_pop(cola_new);

            enviar_codigo_operacion(INIT_PROC, socket_memoria_global);
            send(socket_memoria_global, &pcb->pid, sizeof(int), 0);

            uint32_t largo = strlen(pcb->nombre_archivo) + 1;
            send(socket_memoria_global, &largo, sizeof(uint32_t), 0);
            send(socket_memoria_global, pcb->nombre_archivo, largo, 0);
            send(socket_memoria_global, &pcb->tamanio, sizeof(int), 0);

            bool ok;
            recv(socket_memoria_global, &ok, sizeof(bool), MSG_WAITALL);

            if(ok){
                cambiar_estado(pcb, READY);
                log_info(logger, "## (%d) Pasa del estado NEW al estado READY", pcb->pid);

                pthread_mutex_lock(&mutex_ready);
                queue_push(cola_ready, pcb);
                pthread_mutex_unlock(&mutex_ready);
            } else {
                queue_push(cola_new, pcb);
                break;
            }
        }
        pthread_mutex_unlock(&mutex_new);   //OJO aca, cerre el mutex new porque hacias unlock de mutex ready
    }
}

void finalizar_io_mediano(int pid){
    pcb_t* pcb = buscar_pcb_por_pid(pid);
    if(!pcb) return;

    if(pcb->estado == BLOCKED_SUSPENDED) {
        cambiar_estado(pcb, SUSPENDED_READY);
        pthread_mutex_lock(&mutex_suspended_ready);
        queue_push(cola_suspended_ready, pcb);
        pthread_mutex_unlock(&mutex_suspended_ready);

        log_info(logger, "## <%d> Pasa del estado SUSP. BLOCKED al estado SUSP. READY", pid);
    }else if(pcb->estado == BLOCKED){
        cambiar_estado(pcb, READY);
        pthread_mutex_lock(&mutex_ready);
        queue_push(cola_ready, pcb);
        pthread_mutex_unlock(&mutex_ready);

        log_info(logger, "## <%d> Pasa del estado BLOCKED al estado READY", pid);
    }

    reintentar_ingreso_a_ready(); // podria haber lugar por procesos que finalizaron
}

void inicializar_planificador_mediano_plazo(int socket_memoria){
    socket_memoria_global = socket_memoria;

    pthread_t hilo_suspension;
    pthread_create(&hilo_suspension, NULL, monitor_suspension_blocked, NULL);
    pthread_detach(hilo_suspension);

    log_info(logger, "Planificador de Mediano Plazo inicializado");
}
