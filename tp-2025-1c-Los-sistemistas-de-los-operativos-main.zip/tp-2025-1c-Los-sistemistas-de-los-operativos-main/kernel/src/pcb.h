#include <utils/hello.h>
#ifndef PCB_H_
#define PCB_H_
#include <commons/temporal.h>
#define DESUSPENDER_PROC 4

typedef enum {
    NEW = 0,
    READY= 1,
    EXEC = 2,
    BLOCKED = 3,
    BLOCKED_SUSPENDED = 4,
    SUSPENDED_READY =5,
    EXIT = 6
} estado_proceso_t;

struct pcb;

typedef struct {            //hago esta cosa para hacer un hilo donde se haga el esperar_cliente() sin que interrumpa otras posibles conexiones de cpus
    int socket_procesos;    //es para que cada servidor de procesos este relacionado con su servidor de interrupciones, sino seria un enrriedo
    int socket_interrupciones;   //SI O SI USAR TODAS ESTAS VARIABLES CON EL MUTEX CPUS
    //int id_cpu;   por si queremos tener el numerito de cada CPU asignado
    bool disponible;
    struct pcb* proceso_actual;
} cpu_conectada_t;


typedef struct pcb{
    int pid;
    int tamanio;
    t_list* instrucciones;
    estado_proceso_t estado;
    int pc;
    char* nombre_archivo;


    int metricas_estado[7];
    t_temporal* temporizadores[7];
    int64_t metricas_tiempo[7];  // CAMBIADO: era puntero, ahora es entero directo

    float estimacion;
    float rafaga;
    cpu_conectada_t* cpu_asignada;  // para el tema de las multiples CPU
    t_temporal* temporizador_rafaga;
  
    long ultima_actualizacion;

    char* dispositivo_io;
    int tiempo_io;
    
} pcb_t;




typedef enum {
    FIFO,   
    SJF 
} algoritmo_planificacion_t;



extern t_queue* cola_new;
extern t_queue* cola_ready;
extern t_queue* cola_exec;
extern t_queue* cola_blocked;
extern t_queue* cola_blocked_suspended;
extern t_queue* cola_suspended_ready;
extern t_queue* cola_exit;


void cambiar_estado(pcb_t* pcb, estado_proceso_t estado_nuevo);


#endif