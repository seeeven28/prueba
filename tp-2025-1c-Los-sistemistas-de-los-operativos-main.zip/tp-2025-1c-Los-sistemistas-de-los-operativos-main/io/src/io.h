#include <utils/hello.h>

t_log* iniciar_logger(t_config* config);
t_config* iniciar_config(void);

void enviar_handshake_io(int , const char* , t_log* );
