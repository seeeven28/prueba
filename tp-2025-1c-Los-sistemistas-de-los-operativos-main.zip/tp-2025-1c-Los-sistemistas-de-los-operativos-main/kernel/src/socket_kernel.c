#include <utils/hello.h>
#include <socket_kernel.h>

#define OPCODE_HANDSHAKE_IO 1
#define OPCODE_IO_REQUEST   2
#define OPCODE_IO_FIN       3

int iniciar_kernel_servidor(const char* puerto) {
    int socket_servidor;
    int err;
    struct addrinfo hints, *serverinfo;

    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags = AI_PASSIVE;

    err = getaddrinfo(NULL, puerto, &hints, &serverinfo);
    if (err != 0) {
        perror("[KERNEL]: ERROR GETADDRINFO\n");
        exit(EXIT_FAILURE);
    }

    socket_servidor = socket(serverinfo->ai_family,
                            serverinfo->ai_socktype,
                            serverinfo->ai_protocol);
                                                   
    if (socket_servidor == -1) {
        perror("[KERNEL]: ERROR al crear socket\n");
        freeaddrinfo(serverinfo);
        exit(EXIT_FAILURE);
    }

    err = setsockopt(socket_servidor, SOL_SOCKET, SO_REUSEPORT, &(int){1}, sizeof(int));
    if (err == -1) {
        perror("[KERNEL]: ERROR setsockopt\n");
        close(socket_servidor);
        freeaddrinfo(serverinfo);
        exit(EXIT_FAILURE);
    }

    err = bind(socket_servidor, serverinfo->ai_addr, serverinfo->ai_addrlen);
    if (err == -1) {
        perror("[KERNEL]: ERROR bind\n");
        close(socket_servidor);
        freeaddrinfo(serverinfo);
        exit(EXIT_FAILURE);
    }

    err = listen(socket_servidor, SOMAXCONN);
    if (err == -1) {
        perror("CPU: ERROR listen\n");
        close(socket_servidor);
        freeaddrinfo(serverinfo);
        exit(EXIT_FAILURE);
    }

    freeaddrinfo(serverinfo);
    
    return socket_servidor;
}

int esperar_cliente(int socket_servidor){
    int socket_cliente = accept(socket_servidor, NULL, NULL);
    return socket_cliente;

}

int recibir_operacion(int socket_cliente){
	int cod_op;
    int bytes = recv(socket_cliente, &cod_op, sizeof(int), MSG_WAITALL);
	if (bytes == 0){
		//close(socket_cliente);
		return -1;
	}
	if (bytes == -1) {
		perror("Error en recv");
		//close(socket_cliente);
		return -1;
	}
    
	return cod_op;
}

char* recibir_buffer(int* size, int socket_cliente)
{
    void* buffer;
    recv(socket_cliente, size, sizeof(int), MSG_WAITALL); // Recibe el tamaño primero
    buffer = malloc(*size + 1);  // sumamos 1 para el '\0'
    recv(socket_cliente, buffer, *size, MSG_WAITALL);
    ((char*)buffer)[*size] = '\0';  // terminamos el string correctamente
    return buffer;
}

char* recibir_mensaje(int socket_cliente)
{
    int size;
    char* buffer = recibir_buffer(&size, socket_cliente);

   

    // Copiamos el contenido para no perderlo al liberar
    char* respuesta = strdup(buffer);  // strdup hace malloc + strcpy

    //free(buffer);
    return respuesta;
}

t_list* recibir_paquete(int socket_cliente){
	int size;
	int desplazamiento = 0;
	void * buffer;
	t_list* valores = list_create();
	int tamanio;

	buffer = recibir_buffer(&size, socket_cliente);
	while(desplazamiento < size)
	{
		memcpy(&tamanio, buffer + desplazamiento, sizeof(int));
		desplazamiento+=sizeof(int);
		char* valor = malloc(tamanio);
		memcpy(valor, buffer+desplazamiento, tamanio);
		desplazamiento+=tamanio;
		list_add(valores, valor);
	}
	free(buffer);
	return valores;
}

void liberar_conexion(int socket){
    close(socket);
}




//__________________FUNCIONES PARA KERNEL COMO CLIENTE___________________

int iniciar_kernel_cliente(const char* ip, const char* puerto){
    struct addrinfo hints, *server_info;
    int err;
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags = AI_PASSIVE;
    err = getaddrinfo(ip, puerto, &hints, &server_info);
    if (err != 0) {
        perror("KERNEL: ERROR GETADDRINFO");
        exit(EXIT_FAILURE);
    }
    int fd_conexion = socket(server_info->ai_family,
                            server_info->ai_socktype,
                            server_info->ai_protocol);

    err = connect(fd_conexion, server_info->ai_addr, server_info->ai_addrlen);
    if (err != 0) {
        perror("KERNEL: Error al conectar");
        close(fd_conexion);
    }

    freeaddrinfo(server_info);
	return fd_conexion;
}

void enviar_mensaje(char* mensaje, int socket_cliente)
{
	t_paquete* paquete = malloc(sizeof(t_paquete));

	paquete->codigo_operacion = MENSAJE;
	paquete->buffer = malloc(sizeof(t_buffer));
	paquete->buffer->size = strlen(mensaje) + 1;
	paquete->buffer->stream = malloc(paquete->buffer->size);
	memcpy(paquete->buffer->stream, mensaje, paquete->buffer->size);

	int bytes = paquete->buffer->size + 2*sizeof(int);

	void* a_enviar = serializar_paquete(paquete, bytes);

	send(socket_cliente, a_enviar, bytes, 0);

	free(a_enviar);
	eliminar_paquete(paquete);
}

void crear_buffer(t_paquete* paquete)
{
	paquete->buffer = malloc(sizeof(t_buffer));
	paquete->buffer->size = 0;
	paquete->buffer->stream = NULL;
}

t_paquete* crear_paquete(void)
{
	t_paquete* paquete = malloc(sizeof(t_paquete));
	paquete->codigo_operacion = PAQUETE;
	crear_buffer(paquete);
	return paquete;
}

void agregar_a_paquete(t_paquete* paquete, void* valor, int tamanio)
{
	paquete->buffer->stream = realloc(paquete->buffer->stream, paquete->buffer->size + tamanio + sizeof(int));

	memcpy(paquete->buffer->stream + paquete->buffer->size, &tamanio, sizeof(int));
	memcpy(paquete->buffer->stream + paquete->buffer->size + sizeof(int), valor, tamanio);

	paquete->buffer->size += tamanio + sizeof(int);
}

void enviar_paquete(t_paquete* paquete, int socket_cliente)
{
	int bytes = paquete->buffer->size + 2*sizeof(int);
	void* a_enviar = serializar_paquete(paquete, bytes);

	send(socket_cliente, a_enviar, bytes, 0);

	free(a_enviar);
}

void eliminar_paquete(t_paquete* paquete)
{
	free(paquete->buffer->stream);
	free(paquete->buffer);
	free(paquete);
}

void* serializar_paquete(t_paquete* paquete, int bytes)
{
	void * magic = malloc(bytes);
	int desplazamiento = 0;

	memcpy(magic + desplazamiento, &(paquete->codigo_operacion), sizeof(int));
	desplazamiento+= sizeof(int);
	memcpy(magic + desplazamiento, &(paquete->buffer->size), sizeof(int));
	desplazamiento+= sizeof(int);
	memcpy(magic + desplazamiento, paquete->buffer->stream, paquete->buffer->size);
	desplazamiento+= paquete->buffer->size;

	return magic;
}

void enviar_codigo_operacion(int cod_op, int socket_destino) {


    if (send(socket_destino, &cod_op, sizeof(cod_op), 0) <= 0) {
        perror("Error al enviar código de operación");
    }
}

//________________________

char* recibir_handshake_io(int socket_fd, t_log* logger) {
    uint8_t opcode;
    uint32_t length;

    // 1. Recibir el opcode
    if (recv(socket_fd, &opcode, sizeof(uint8_t), MSG_WAITALL) <= 0) {
        log_error(logger, "Error al recibir el opcode del handshake");
        return NULL;
    }

    if (opcode != OPCODE_HANDSHAKE_IO) {
        log_error(logger, "Opcode inesperado: %d", opcode);
        return NULL;
    }

    // 2. Recibir la longitud del nombre
    if (recv(socket_fd, &length, sizeof(uint32_t), MSG_WAITALL) <= 0) {
        log_error(logger, "Error al recibir la longitud del nombre");
        return NULL;
    }

    // 3. Reservar memoria para el nombre y recibirlo
    char* nombre = malloc(length);
    if (recv(socket_fd, nombre, length, MSG_WAITALL) <= 0) {
        log_error(logger, "Error al recibir el nombre");
        free(nombre);
        return NULL;
    }

    log_info(logger, "Handshake recibido desde IO con nombre: %s", nombre);
    return nombre; // No te olvides de free() cuando termines de usarlo
}

void enviar_peticion_io(int socket_io, uint32_t pid, uint32_t tiempo) {

    send(socket_io, &pid, sizeof(int), 0);
    send(socket_io, &tiempo, sizeof(int), 0);
}

